# Kiểm toán 100% nội dung bộ `in-this-town-kit-v2.zip`

> Chỉ đọc trực tiếp 64 tệp nằm trong ZIP V2 người dùng tải lên; không đọc, import hoặc tái sử dụng bản V1 hay video/kịch bản cũ. Hai tệp ví dụ legacy có trong ZIP V2 chỉ được kiểm tra tính hợp lệ, không được lấy làm nguồn cho bản test.

## Tổng quan

- Đã mở và xác thực SHA-256: **64/64 tệp**.
- Python: **28**, JSON: **11**, SRT: **10**, PNG: **8**, tài liệu/khác: **7**.
- Tệp lỗi dữ liệu/giải mã: **0**.
- `tools/_codex/rig_probe.py` và `measure_stills.py` có BOM UTF-8, parser Python đọc được; không phải lỗi file.

## Chỉ số tập V2 đã kiểm tra

| Tập | Cảnh | Giây | Lời thoại | Bộ bối cảnh |
|---|---:|---:|---:|---|
| 1 — Tập 1 — Đọc Ý Đồ | 154 | 148.52 | 77 | bedroom, cellar, class, hall, kitchen, park, street |
| 2 — Tập 2 — Bóng Rời Chân | 151 | 152.69 | 70 | bedroom, class, kitchen, park, shop, street |
| 3 — Tập 3 — Số Trên Đầu | 156 | 155.53 | 70 | bedroom, class, kitchen, park, shop, street |
| 4 — Tập 4 — Loa Phường | 145 | 144.81 | 71 | bedroom, cellar, class, hall, kitchen, park, shop, street |
| 5 — Tập 5 — Cái Cân Chợ | 147 | 142.16 | 72 | bedroom, cellar, class, hall, kitchen, park, shop, street |
| 6 — Tập 6 — Ghế Đá | 151 | 148.6 | 71 | bedroom, cellar, class, hall, kitchen, park, street |
| 7 — Tập 7 — Bảng Đen | 150 | 147.19 | 71 | bedroom, cellar, class, hall, kitchen, park, street |
| 8 — Tập 8 — Cửa Nhà | 146 | 145.14 | 71 | bedroom, cellar, class, hall, kitchen, park, shop, street |
| 9 — Tập 9 — Đồng Hồ Ngược | 155 | 151.7 | 71 | bedroom, cellar, class, hall, kitchen, park, street |
| 10 — Tập 10 — Ảnh Gia Đình | 161 | 159.45 | 71 | bedroom, cellar, class, hall, kitchen, park, shop, street |

## Kết quả đối chiếu phụ đề V2

| Tệp | Câu phụ đề | Cue cuối |
|---|---:|---|
| data/ep01-subs.srt | 77 | 00:02:25,470 |
| data/ep02-subs.srt | 70 | 00:02:32,640 |
| data/ep03-subs.srt | 70 | 00:02:35,480 |
| data/ep04-subs.srt | 71 | 00:02:24,760 |
| data/ep05-subs.srt | 72 | 00:02:22,110 |
| data/ep06-subs.srt | 71 | 00:02:28,550 |
| data/ep07-subs.srt | 71 | 00:02:27,140 |
| data/ep08-subs.srt | 71 | 00:02:24,220 |
| data/ep09-subs.srt | 71 | 00:02:31,650 |
| data/ep10-subs.srt | 71 | 00:02:39,400 |

## Toàn bộ texture V2

| File | Kích thước | Mode |
|---|---|---|
| `build/tex/alarm_late.png` | 512×256 | RGBA |
| `build/tex/alarm_nine.png` | 512×256 | RGBA |
| `build/tex/clock.png` | 1024×1024 | RGBA |
| `build/tex/faces.png` | 2048×2048 | RGBA |
| `build/tex/lightsout.png` | 1024×512 | RGBA |
| `build/tex/nocoffee.png` | 1024×1024 | RGBA |
| `build/tex/poster_rocket.png` | 512×720 | RGBA |
| `build/tex/poster_sleep.png` | 512×720 | RGBA |

## Tất cả file Python V2: đã đọc và phân tích AST

| Tệp | Bytes | Hàm/lớp top-level | Hàm/lớp đại diện | Import đại diện |
|---|---:|---:|---|---|
| `make.py` | 2276 | 2 | run, main | sys, os, json, time, subprocess, glob |
| `rt_cam.py` | 7043 | 5 | _hit_count, _inside, _resolve, _base, apply | math, bpy, rt_engine, rt_rigs |
| `rt_engine.py` | 54883 | 31 | clamp, lerp, lerp3, ease, ease_out | bpy, bmesh, math, os, mathutils |
| `rt_faces.py` | 16147 | 15 | P, eye, closed, brow, mouth_arc | os, math, skia |
| `rt_finish.py` | 8800 | 5 | cards, Captions, grade, speed_lines, main | sys, os, json, subprocess, re, math, numpy, cv2, PIL |
| `rt_render.py` | 5049 | 4 | opt, shot_times, frame, render | sys, os, json, time, importlib.util, bpy, rt_engine |
| `rt_rigs.py` | 8682 | 5 | back_for, _build, mark_pos, face_camera, _lerp | math |
| `rt_sets.py` | 13081 | 11 | Set, _room, street, park, hall | rt_engine, rt_engine, rt_rigs |
| `rt_sheet.py` | 1009 | 0 |  | os, sys, glob, cv2, numpy |
| `rt_story.py` | 4964 | 4 | Ctx, _seed, _mk_char, driver | json, math, os, bpy, mathutils, rt_engine, rt_cam, rt_rigs, rt_sets |
| `rt_voice.py` | 4912 | 4 | speak, pcm, build, main | sys, os, json, asyncio, subprocess, re, time, numpy, edge_tts |
| `verify.py` | 4615 | 3 | chk, load, main | json, os, sys, rt_rigs |
| `stories/ep01.py` | 224 | 0 |  | os, rt_story |
| `stories/ep02.py` | 224 | 0 |  | os, rt_story |
| `stories/ep03.py` | 224 | 0 |  | os, rt_story |
| `stories/ep04.py` | 224 | 0 |  | os, rt_story |
| `stories/ep05.py` | 224 | 0 |  | os, rt_story |
| `stories/ep06.py` | 224 | 0 |  | os, rt_story |
| `stories/ep07.py` | 224 | 0 |  | os, rt_story |
| `stories/ep08.py` | 224 | 0 |  | os, rt_story |
| `stories/ep09.py` | 224 | 0 |  | os, rt_story |
| `stories/ep10.py` | 224 | 0 |  | os, rt_story |
| `stories/last_one_awake.py` | 20807 | 29 | Ctx, build, reset, light, zzz | math, rt_engine, rt_engine |
| `tools/audit_numbers.py` | 3911 | 1 | check | glob, json, os, re, sys, rt_rigs, zipfile |
| `tools/framing_check.py` | 6717 | 4 | measure, inside_solid, blocked, verdict | glob, json, os, sys, bpy, mathutils, bpy_extras.object_utils, rt_engine, rt_rigs, rt_cam |
| `tools/make_stories.py` | 4263 | 3 | src_csv, move_of, convert | csv, glob, json, os, shutil |
| `tools/_codex/measure_stills.py` | 1056 | 0 |  | glob, sys, os, bpy, numpy |
| `tools/_codex/rig_probe.py` | 1525 | 1 | Context | os, sys, bpy, mathutils, bpy_extras.object_utils, rt_engine, rt_sets, rt_story, rt_rigs, rt_cam |

## Tất cả file JSON V2

- `stories/ep01.json`: 154 cảnh, 148.52 s, voice=vi-VN-NamMinhNeural
- `stories/ep02.json`: 151 cảnh, 152.69 s, voice=vi-VN-NamMinhNeural
- `stories/ep03.json`: 156 cảnh, 155.53 s, voice=vi-VN-NamMinhNeural
- `stories/ep04.json`: 145 cảnh, 144.81 s, voice=vi-VN-NamMinhNeural
- `stories/ep05.json`: 147 cảnh, 142.16 s, voice=vi-VN-NamMinhNeural
- `stories/ep06.json`: 151 cảnh, 148.6 s, voice=vi-VN-NamMinhNeural
- `stories/ep07.json`: 150 cảnh, 147.19 s, voice=vi-VN-NamMinhNeural
- `stories/ep08.json`: 146 cảnh, 145.14 s, voice=vi-VN-NamMinhNeural
- `stories/ep09.json`: 155 cảnh, 151.7 s, voice=vi-VN-NamMinhNeural
- `stories/ep10.json`: 161 cảnh, 159.45 s, voice=vi-VN-NamMinhNeural
- `stories/last_one_awake.json`: 17 cảnh, 20 s, voice=en-US-AndrewNeural

## Tất cả file tài liệu/cấu hình V2

- `AGENTS.md`: 44 dòng, 3617 bytes — đọc được
- `CHANGELOG-V1-V2.md`: 76 dòng, 5052 bytes — đọc được
- `CLAUDE.md`: 3 dòng, 76 bytes — đọc được
- `GEMINI.md`: 3 dòng, 76 bytes — đọc được
- `README.md`: 126 dòng, 6405 bytes — đọc được
- `V2-MAP.md`: 107 dòng, 7573 bytes — đọc được
- `requirements.txt`: 5 dòng, 48 bytes — đọc được

## Vấn đề thực tế ảnh hưởng sản xuất

1. **Chưa thể kết luận 1516 cảnh đều hiển thị trong bản xuất**: `rt_render.py/shot_times()` cho cảnh trống lời mốc cắt bằng mốc cảnh trước, khiến nhiều cảnh thoại thành đoạn 0-frame. Tập 3 tái hiện được 69/156 cảnh 0-frame với bộ mốc từ V2 `dur` giả lập; cần kiểm tra lại bằng voice thật và dùng bản vá riêng cho test.
2. `make.py --preview` **không phải clip ngắn**, mà vẫn làm cả story ở 50% độ phân giải. Bản test chọn 13 shot gốc, full 1080×1920 24fps, không dùng --preview.
3. `rt_render.py` đọc `build/words.json` nên **không có voice thật thì không thể dựng timeline gốc đúng**. Các `data/epNN-subs.srt` không thay thế timestamps word-by-word.
4. `rt_finish.py` tái sử dụng frame trước nếu frame thiếu. Bộ test đã bổ sung kiểm tra **không thiếu bất kỳ frame nào** trước khi chạy bước finish.
5. CPU Cycles denoise có khác biệt API giữa phiên bản Blender; bản test chỉ vá runtime để dùng `view_layers[].cycles.use_denoising` khi hỗ trợ, không sửa mã V2 gốc.
6. Chưa thấy `LICENSE` trong archive V2. **Không khẳng định quyền tái phân phối toàn bộ mã/ảnh lên repo public**; nên dùng workspace/repo private nếu render trên Cloud.
7. `rt_voice.py` sử dụng edge-tts online: phải có kết nối mạng và người dùng cần tự xem điều kiện sử dụng trước khi đăng nội dung thương mại; không thay voice bằng âm thanh tự tạo/không đồng bộ.
8. Bộ này không có Blender và không truy cập được internet ở môi trường kiểm thử hiện tại; chưa thể chạy `framing_check.py` bằng Blender hoặc xuất MP4 3D thật ngay tại đây.

## File kiểm kê đủ 64 tệp V2 (không có ngoại lệ)

| Đường dẫn | Bytes | SHA-256 |
|---|---:|---|
| `AGENTS.md` | 3617 | `9abc46e67a07b735e706bd5a94e519c5316509e40e5b4c2aa607bccb116729d2` |
| `CHANGELOG-V1-V2.md` | 5052 | `6a33f2c05afa3a5f7e8a79f20adc9330e456f6ccad63b5574431977d6283b928` |
| `CLAUDE.md` | 76 | `5141415ea23e5918b45997e841178836b12840ea216e24fb7d8bd5a129a22080` |
| `GEMINI.md` | 76 | `5141415ea23e5918b45997e841178836b12840ea216e24fb7d8bd5a129a22080` |
| `README.md` | 6405 | `943d3a8de6e8a5bfe1dca8a0bc92a0ea35dfe300fa749a54e85971ab8127f873` |
| `V2-MAP.md` | 7573 | `c24743958b8c6fbaab5955c9d8c53edd170d799683c7dabae32f89353e7926e9` |
| `make.py` | 2276 | `a5b687bc5a67adab731a3eb16109df616708bbc39a96cb21b16fad71745564d7` |
| `requirements.txt` | 48 | `adcc93ee9220a38ab7eeb33fd76e860108a199afe7592f3396747fa99dafea0c` |
| `rt_cam.py` | 7043 | `efb1a8f581f819b3c5bef1e52ce8e80fa7bb1d3705c618656ba5ab2789eabaf4` |
| `rt_engine.py` | 54883 | `0b15563c7df08d261083a6cc71e23db7a9d846c10b2b08aa1551a4288e6084d4` |
| `rt_faces.py` | 16147 | `270aea4eb9b889955039d254b939dae2cb9aef1b05816fa9679583d060a501b8` |
| `rt_finish.py` | 8800 | `30c5c6ead5f570fd08056fb2a2fc459c35ebd546ce4dcb1424c3bb7bd6d3ebc6` |
| `rt_render.py` | 5049 | `cee64bd277dbcad08515e58b00fc977a67456bd2268efc73132667c83ea66368` |
| `rt_rigs.py` | 8682 | `0782a3071033f03023b27506257842ac0c26050fc709387e538a34e146483c86` |
| `rt_sets.py` | 13081 | `cf7b6bda31e503c9c5061b5a4af963b05add466dd058e46694ce0ed33922fb28` |
| `rt_sheet.py` | 1009 | `7d33309ae3f74af43174c93115a97f00c20b76696ba49f57bf083e153f10eb08` |
| `rt_story.py` | 4964 | `0f41befcbb06db8048249f2a8705794c460aabb65546f1ea61923f6f31a0a354` |
| `rt_voice.py` | 4912 | `710755b4523e1de53056a5001fc13c970bd38c24fe44cb5a2a9e54402399ea8f` |
| `verify.py` | 4615 | `3f3ebbb9120e6bd917fce0b792fc6590d5a21ab56bc38ed3a91e00a7e30730b2` |
| `build/tex/alarm_late.png` | 5899 | `f97c85262fa10e813d5cbd51fd01d833c701ba0efb48009f2b5696b6e16b785c` |
| `build/tex/alarm_nine.png` | 7746 | `08e5332bb4418e23cec48972dd1c86cf13f8e4f359ed881837ba91ba658c4540` |
| `build/tex/clock.png` | 90763 | `f7a55167e0f7d23759968cd6714b5acc6d17a0378b7bb797daf2cb41c38746e0` |
| `build/tex/faces.png` | 242554 | `9f9a55055cf6a6a85e1292de4a33f6c8049efd451d743ee02df883b67450e627` |
| `build/tex/lightsout.png` | 16515 | `e0e74d9a364b2842c5f89c33d233ecd95763cf9b8152bd748bb2eb0b7e7199ce` |
| `build/tex/nocoffee.png` | 56933 | `c164f136c28bccb227e6f09913c972c098432979b898a2720ac6948e08a53a13` |
| `build/tex/poster_rocket.png` | 26367 | `317375b55965ae0b6d9300fd64337c3424c07c3f18ff7e1e1c6d530cee82366b` |
| `build/tex/poster_sleep.png` | 22329 | `b9f91cbc89b533e27db7691af4f0484806aaa6946b3165649edff7776e71bd0f` |
| `data/ep01-subs.srt` | 5345 | `46982801acaf89dab9abb8dbf38e082a2d0b10f1d75169464abab706cbc35a37` |
| `data/ep02-subs.srt` | 4999 | `4d1de6b996314b8798367c1611858f4edc83a0537f216c4cb036fbfecb1a0ecd` |
| `data/ep03-subs.srt` | 5058 | `cac28e4eff3b54b294b46e32baae18b952a309b9a19f5479ce1512846277142e` |
| `data/ep04-subs.srt` | 4918 | `6988bc0ea54c7ac030e8b5f369343ccf5ddfde63f75b2f8fd9d4e38a48180ea9` |
| `data/ep05-subs.srt` | 4889 | `8d56346ac7fe88c5edc67ac2f51c3197a9d71fc755ff2a865c87b4b0252af9c0` |
| `data/ep06-subs.srt` | 5020 | `f3404abfaafdfa5cf95ee59170e305c9d485b2cf813db79792bc0ca241ada505` |
| `data/ep07-subs.srt` | 5038 | `de0ecdcc531ded6aed6700c89295ef72986461019b072b5e2d23e1f1d362bf7e` |
| `data/ep08-subs.srt` | 4897 | `c88ffc41409c2f06554a07018522b27d1c2db088e293478b04783c83158bfda8` |
| `data/ep09-subs.srt` | 5028 | `8f2e3486070a926578a652a7368cc620ea7c8a910a9bb1329614bf480ccd7ca1` |
| `data/ep10-subs.srt` | 5128 | `1377916fe2fa0bcf1111d5a3d15a70190e20fb87efee189b22c41f80d715fc7e` |
| `stories/ep01.json` | 53195 | `3658d41221f33bc492949c63cb9b29b133860d1fd08175046746497eed0a9909` |
| `stories/ep01.py` | 224 | `c053f4eece0b3c756f4d9057d416b7c8c6f74500b011a2246b1865ac8dcaa7ab` |
| `stories/ep02.json` | 52642 | `fe3af0329473d91c60b6b2307b1f40308e966e322f4dc19ec731f39dd35f6c1c` |
| `stories/ep02.py` | 224 | `3960a83369af1d4f924d5f70c2bc059a43719b1e822d851566d40b3434ad6eed` |
| `stories/ep03.json` | 53336 | `a790c5e883d9bd1b5dd5f713323c7e6234cadd9d50349499d34eca3861b00135` |
| `stories/ep03.py` | 224 | `0dfbcef12d1b0b698f87a4441718ab17a6dfe9da5a4bc9584338630d20b8c86b` |
| `stories/ep04.json` | 50007 | `b28ab1bb311d5f7afc3b42aba0feccff29e5fb4e4b21c4dd153a76fb3c484cf6` |
| `stories/ep04.py` | 224 | `4d1c4abeeeac172088290216069c2a7d40d3320036776c4683a82429097e2401` |
| `stories/ep05.json` | 51178 | `aa1b50ec31ef0e0b0648c856c17e8d0253889c0c0d2ddc9883e2047cc18c9a66` |
| `stories/ep05.py` | 224 | `7d7cac2062d656ef9d0f084940fd17629254dcdc3c4b0ef2a5200c600ac0efe5` |
| `stories/ep06.json` | 52130 | `4af2b17a63239dfa69f527541dbc629dba09b7f34996e341aa28eb7a6a60efe9` |
| `stories/ep06.py` | 224 | `e54979b11688e1e3a4baee63650375f6d79a3d0a071187abef62b2a9c11f8c1d` |
| `stories/ep07.json` | 51729 | `e9bb10bbc41d7b33b8fd58c425e17380162f6f4dae9df28cca0018ef668b00a6` |
| `stories/ep07.py` | 224 | `3e81f2bcaddcd8b9e11beeffd3e640d37fde4e2ea2e2e511158c11f545cb44b1` |
| `stories/ep08.json` | 51367 | `cd19a5c890f3f281f514db5b81a745af0b437dba7b1ad3044f6d5fb89aba3dcd` |
| `stories/ep08.py` | 224 | `0d38d72276fe908a2896b68be9eb4c14e5dca6cbae20b9064f96cbb97556b82f` |
| `stories/ep09.json` | 54437 | `1682c4b9a9552650d0f7e9bef8d4801c85c82521ec1fbbbe17e201c655d31c29` |
| `stories/ep09.py` | 224 | `7dee1e27d602a8aae3870e6b8c1ffdfafc17aa1f001c70b9440ac5e5cadf5dea` |
| `stories/ep10.json` | 56600 | `5c129b45a24ac556758674525dfbaa98b50936ae9ca467b21faea3a2fcec943b` |
| `stories/ep10.py` | 224 | `f96e18f36e92fe66205c411466df677146489c481036ae9fe5ed6706848f94d9` |
| `stories/last_one_awake.json` | 1228 | `541c572bf0f0e0f4dc0da571e03dd750dfd27b5c9bc8a8c47e66e8a5f05973c9` |
| `stories/last_one_awake.py` | 20807 | `76f5051179539203f34d3645a9e9cf7c6cef5bc5eded38912c3755ae60818d67` |
| `tools/audit_numbers.py` | 3911 | `9a5090bd5b2ad6e1c39d1420466fb4043f733a1ab5f4f2922cea47649e317f4f` |
| `tools/framing_check.py` | 6717 | `02d663e8ff36778044b319a93ffad3408ab812d529ac23ad3468ae39e98b4f26` |
| `tools/make_stories.py` | 4263 | `db5b7d8d2d03eeee3fefdd2b1c68c76ded7bd6d839a5b46d94067323afacce53` |
| `tools/_codex/measure_stills.py` | 1056 | `6dffce32ce8c10ff1f1124a03431e7b1564e07500383227bd00ed3e9dcc7cd72` |
| `tools/_codex/rig_probe.py` | 1525 | `4db3bdaf695719864e91c3ada6e59257468f7993519a6701860209a133bf215f` |

## Lỗi nguồn/kiểm toán

Không có lỗi parse/giải mã/hash trên 64 file gốc.
