@echo off
cd /d "%~dp0"
where gh >nul 2>&1
if errorlevel 1 (
  echo GitHub CLI is required. Installing with winget if available...
  winget install --id GitHub.cli --exact --accept-source-agreements --accept-package-agreements
  echo Reopen this script after installing GitHub CLI.
  pause
  exit /b 1
)
where git >nul 2>&1
if errorlevel 1 (
  echo Git is required. Installing with winget if available...
  winget install --id Git.Git --exact --accept-source-agreements --accept-package-agreements
  echo Reopen this script after installing Git.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_V2_CLOUD_NOW.ps1"
if errorlevel 1 (
  echo Cloud bootstrap did not finish. Review error above.
  pause
  exit /b 1
)
echo GitHub Actions render request was submitted.
pause
