# V2-only production Cloud test — one-click deployment

## Run

On Windows, extract the ZIP, open **in-this-town-kit-v2**, and double-click `RUN_V2_CLOUD_NOW.cmd`.

- Git and GitHub CLI must be available. If missing, the launcher attempts to install via Windows `winget`; reopen it after installation.
- First run may ask you to log in on the official GitHub website. Do not share passwords or tokens with ChatGPT.
- Script verifies SHA-256 of **all 64 ORIGINAL V2 files** and creates a **NEW PRIVATE repository**: `in-this-town-kit-v2-test-20261120`.
- If that repo exists, script refuses to overwrite anything. Existing V1 repositories/files are never accessed.
- After pushing, it **automatically triggers** `v2-real-production-test.yml`.
- Monitor GitHub Actions. It will do full V2 audits, 44 camera rigs, 1516 scene framing checks, real Vietnamese Edge TTS, 8 original textures, 39 3D stills, **one full-resolution frame** benchmark, **three parallel Blender jobs rendering 95 real frames each**, and original V2 grading with word-by-word Vietnamese captions.
- On success, download artifact **`V2-ep03-real-3D-test-11s`** (FINAL.mp4 and .srt). This is a **11.87-second pilot**, not full episode.

## Publishing

Default is **PRIVATE** because the uploaded V2 kit has no explicit redistribution license. If you own the original code and textures and explicitly choose to make all 64 files public, run `powershell -ExecutionPolicy Bypass -File .\RUN_V2_CLOUD_NOW.ps1 -Public` from its directory instead. Public availability of the finished video is a separate decision.

## Quality limits

This is genuine 1080×1920 CPU Cycles rendering using original V2 code, not a replacement style. Render speed and Edge TTS access depend on GitHub and may fail; inspect logs and final artifact before calling the video complete. GitHub Actions has plan-based billing and usage limits. The 180-minute job timeout is a ceiling, not a render estimate.
