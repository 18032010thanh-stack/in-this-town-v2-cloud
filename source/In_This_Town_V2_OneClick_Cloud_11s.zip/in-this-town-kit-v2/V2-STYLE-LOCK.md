# V2-ONLY style and source lock

This **production preview must use only the 64 original files in `in-this-town-kit-v2.zip`** as its creative/technical source. Source hashes are tracked in `V2-SOURCE-MANIFEST.json`. The original source files are not edited; narrowly scoped Blender compatibility and silent-shot timing patches are applied to the isolated `_runtime_v2` copy only.

## Visual style (from this V2 kit's `README.md` and `AGENTS.md`)

- Roblox-like **blocky proportions** built with the kit's original `rt_engine.py` `Char`, not any Roblox franchise asset. Head approximately two-thirds of torso width; not oversized heads/eyes.
- Dark clothes, dark or strongly colored hair, strong blacks; **no pastel/toddler/toy visual style**.
- Textured brick, siding, planks, fabric and grass. Sharp, crisp block edges; no added smooth, rounded aesthetic.
- The **8 V2 sets** from `rt_sets.py`, all placement marks from `rt_rigs.py`, and **44 V2 camera rigs**; V2 camera motion from `rt_cam.py`. No hand-made alternate camera system.
- Story beats, characters, props, setting, cast positions, poses and facial expressions solely from the original `stories/ep03.json` through the original V2 driver `rt_story.py`. Use original `rt_faces.py` textures and face presets; do not replace with stock or generated media.
- Rapid camera cuts and expression changes according to original V2 timing. The 11.87s preview uses original episode 03's 13 shots, with a runtime-only fix to keep silent beats nonzero-duration.
- **1080×1920, 24 FPS**, native vertical output. Vietnamese `vi-VN-NamMinhNeural` narration, **word-by-word captions**: 2–3 words, white letters black edge, current spoken word yellow, below the face. **Voice only; no music, no sound effects**.

## Explicit exclusions

- **Never use the prior standalone 2D town animatic, Robot Seed, other scripts, storylines, image/video assets, or any V1 repository.**
- Files with historical `V1` mentions **inside the supplied V2 archive** are part of the V2 documentation or inherited V2 infrastructure. This does not authorize importing any file from a separate V1 package or repository.
- Do not change the original 64 V2 source files. Do not publish this kit to a public repository before licensing is clarified.
- A passing static audit **does not** prove rendered visual fidelity: inspect `build/stills/_sheet*.jpg` and the final MP4 before calling the preview accepted.

## Cloud acceptance checks

1. `tools/v2_audit_all.py` validates all 64 source hashes; `verify.py --strict`, `tools/audit_numbers.py` and the local tests pass.
2. Runtime sample matches V2 `ep03.json` shots `s001–s013`; 13 real Blender scenes with the original V2 engine, sets, cameras and textures.
3. Real Edge TTS and word timings, all 8 original texture surfaces, 3 stills per scene inspected.
4. Full-resolution 1080×1920 frames plus true 11.87-second H.264/AAC MP4; verify frame count/duration, and check no blank/incorrect shots.
5. No edit or write to V1 repositories, and no full-episode render.
