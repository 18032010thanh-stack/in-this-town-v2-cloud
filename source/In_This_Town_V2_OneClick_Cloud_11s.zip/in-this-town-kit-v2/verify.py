"""verify.py — 14 phép kiểm, in PASS/FAIL. Không cần Blender, không cần mạng.

    python verify.py            # kiểm tĩnh: số cảnh, thời lượng, rig, mark, mặt, nhịp
    python verify.py --strict   # coi cảnh báo là lỗi

Mỗi dòng là một khẳng định có thể SAI. FAIL nghĩa là zip này chưa đúng như đã thống nhất:
tập 1 phải là 154 cảnh / 148,5 s / 0,96 s, cả 10 tập 1516 cảnh / 1495,8 s.
"""
import json
import os
import sys

import rt_rigs

HERE = os.path.dirname(os.path.abspath(__file__))
EXPECT = {1: (154, 148.5), 2: (151, 152.7), 3: (156, 155.5), 4: (145, 144.8), 5: (147, 142.2),
          6: (151, 148.6), 7: (150, 147.2), 8: (146, 145.1), 9: (155, 151.7), 10: (161, 159.4)}
SETS = ["street", "hall", "class", "park", "shop", "kitchen", "bedroom", "cellar"]
FACES = {"smile", "shock", "sad", "tired", "tuc", "worry", "calm", "normal"}

rows = []


def chk(no, name, ok, detail=""):
    rows.append((no, name, bool(ok), detail))


def load(n):
    p = os.path.join(HERE, "stories", "ep%02d.json" % n)
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else None


def main():
    stories = {n: load(n) for n in EXPECT}
    all_shots = []

    chk(1, "có đủ 10 file stories/epNN.json", all(stories.values()),
        ", ".join("ep%02d" % n for n in EXPECT if not stories[n]) or "đủ 10")

    bad_count, bad_sec = [], []
    for n, (want_c, want_s) in EXPECT.items():
        s = stories[n]
        if not s:
            continue
        c, sec = len(s["shots"]), round(sum(x["dur"] for x in s["shots"]), 1)
        if c != want_c:
            bad_count.append("ep%02d %d≠%d" % (n, c, want_c))
        if abs(sec - want_s) > 0.3:
            bad_sec.append("ep%02d %.1f≠%.1f" % (n, sec, want_s))
        all_shots += [(n, x) for x in s["shots"]]
    chk(2, "số cảnh mỗi tập khớp bộ đã đo", not bad_count, ", ".join(bad_count) or "10/10")
    chk(3, "thời lượng mỗi tập khớp bộ đã đo", not bad_sec, ", ".join(bad_sec) or "10/10")

    chk(4, "tổng 1516 cảnh / 1495,8 s", len(all_shots) == 1516 and
        abs(sum(x["dur"] for _, x in all_shots) - 1495.8) < 1.0,
        "%d cảnh, %.1f s" % (len(all_shots), sum(x["dur"] for _, x in all_shots)))

    miss_a = sorted({x["anchor"] for _, x in all_shots} - set(rt_rigs.RIGS))
    chk(5, "mọi anchor có rig", not miss_a, ",".join(miss_a[:6]) or "%d rig" % len(rt_rigs.RIGS))

    miss_to = sorted({x["to"] for _, x in all_shots if x.get("to")} - set(rt_rigs.RIGS))
    chk(6, "mọi `to` (lia máy) có rig", not miss_to, ",".join(miss_to[:6]) or "ok")

    miss_mk = sorted({m for _, x in all_shots for m in (x.get("cast") or {}).values()}
                     - set(rt_rigs.MARKS))
    chk(7, "mọi mark đặt cast tồn tại (24 mark)", not miss_mk, ",".join(miss_mk[:6]) or "24 mark")

    miss_set = sorted({x["set"] for _, x in all_shots} - set(SETS))
    chk(8, "mọi bối cảnh có set dựng sẵn", not miss_set, ",".join(miss_set[:6]) or "8 set")

    no_cast = [(n, x["id"]) for n, x in all_shots if not x.get("cast")]
    chk(9, "cảnh nào cũng có người", not no_cast,
        ", ".join("ep%02d/%s" % t for t in no_cast[:4]) or "%d cảnh" % len(all_shots))

    bad_face = sorted({f for _, x in all_shots for f in (x.get("exp") or {}).values()} - FACES)
    chk(10, "biểu cảm chỉ dùng 8 preset", not bad_face, ",".join(bad_face) or "8/8")

    s01 = stories[1]["shots"]
    rata = sum(x["dur"] for x in s01) / len(s01)
    chk(11, "tập 1: 0,90–1,00 s/cảnh", 0.90 <= rata <= 1.00, "%.2f s" % rata)

    push = sum(1 for _, x in all_shots if x.get("fovTo")) / len(all_shots)
    chk(12, "push-in 50–70% tổng số cảnh", 0.50 <= push <= 0.70, "%.0f%%" % (push * 100))

    dutch = sum(1 for _, x in all_shots if x.get("dutch")) / len(all_shots)
    chk(13, "dutch 10–25% tổng số cảnh", 0.10 <= dutch <= 0.25, "%.0f%%" % (dutch * 100))

    law = sum(1 for _, x in all_shots if x.get("law")) / len(all_shots)
    chk(14, "≥85% cảnh có vệt luật", law >= 0.85, "%.0f%%" % (law * 100))

    width = max(len(r[1]) for r in rows) + 2
    fails = 0
    for no, name, ok, detail in rows:
        fails += 0 if ok else 1
        print("%2d %-*s %-4s %s" % (no, width, name, "PASS" if ok else "FAIL", detail))
    print("\n%d/%d PASS" % (len(rows) - fails, len(rows)))
    if fails and "--strict" in sys.argv:
        sys.exit(1)


if __name__ == "__main__":
    main()
