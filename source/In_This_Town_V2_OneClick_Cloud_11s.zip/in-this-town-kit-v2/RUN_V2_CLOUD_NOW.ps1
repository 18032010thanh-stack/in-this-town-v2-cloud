# Isolated and original V2-only 11.87-second Cloud production test.
# No existing GitHub repositories or V1 files are touched.
param([string]$RepoName = 'in-this-town-kit-v2-test-20261120', [switch]$Public)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
function Must([string]$Label) {
  if ($LASTEXITCODE -ne 0) { throw "$Label failed with exit code $LASTEXITCODE" }
}
function Has([string]$Name) { return [bool](Get-Command $Name -ErrorAction SilentlyContinue) }
if (-not (Has 'gh')) { throw 'GitHub CLI missing. Run winget install --id GitHub.cli --exact, reopen terminal and rerun.' }
if (-not (Has 'git')) { throw 'Git missing. Run winget install --id Git.Git --exact, reopen terminal and rerun.' }
if (Test-Path .git) { throw 'Refusing to use a folder with .git. Extract a fresh copy of this ZIP.' }
if (-not (Test-Path 'V2-SOURCE-MANIFEST.json')) { throw 'Missing V2 manifest: run inside kit folder.' }
$Manifest = Get-Content -Raw -Encoding UTF8 V2-SOURCE-MANIFEST.json | ConvertFrom-Json
$Count=0
foreach ($Entry in $Manifest.source_files.PSObject.Properties) {
  $Relative=[string]$Entry.Name
  $Absolute=Join-Path $PSScriptRoot ($Relative.Replace('/',[IO.Path]::DirectorySeparatorChar))
  if (-not (Test-Path -LiteralPath $Absolute -PathType Leaf)) { throw "Missing V2 original file $Relative" }
  if ((Get-Item -LiteralPath $Absolute).Length -ne [long]$Entry.Value.bytes) { throw "Changed V2 size $Relative" }
  $Actual=(Get-FileHash -LiteralPath $Absolute -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($Actual -ne [string]$Entry.Value.sha256) { throw "V2 changed SHA256 $Relative" }
  $Count++
}
if ($Count -ne 64) { throw "Expected 64 original V2 files, found $Count" }
Write-Host 'Verified ALL 64 original V2 files, no outside assets.' -ForegroundColor Green
& gh auth status *> $null
if ($LASTEXITCODE -ne 0) {
  Write-Host 'GitHub login required. Browser will open for secure authorization.'
  & gh auth login --hostname github.com --web --git-protocol https
  Must 'gh auth login'
}
$Owner=((& gh api user --jq .login) | Out-String).Trim()
Must 'GitHub profile'
if (-not $Owner) { throw 'Could not detect GitHub username' }
if ($RepoName -notmatch '^[a-zA-Z0-9_.-]+$') { throw 'Invalid repository name' }
$Repo="$Owner/$RepoName"
& gh repo view $Repo --json name --jq .name *> $null
if ($LASTEXITCODE -eq 0) { throw "Repository $Repo already exists; refusing to overwrite another project." }
if ($Public) {
  Write-Host 'WARNING: --Public means ALL V2 files and PNG textures will be publicly readable!' -ForegroundColor Yellow
  Write-Host 'Use only if you own or have publishing rights for these original files.' -ForegroundColor Yellow
  $Visibility='--public'
} else {
  $Visibility='--private'
}
& git init -b main
Must 'git init'
& git add -A
Must 'git add'
$UserID=((& gh api user --jq .id) | Out-String).Trim()
Must 'GitHub user ID'
& git -c "user.name=$Owner" -c "user.email=$UserID+$Owner@users.noreply.github.com" commit -m 'Original V2-only 11.87 second real Blender production test'
Must 'git commit'
& gh repo create $Repo $Visibility --source . --remote origin --push --description 'Original V2 3D test, 13 shots and cloud render'
Must 'Create and push isolated repo'
Write-Host "REPO: https://github.com/$Repo" -ForegroundColor Green
$Started=$false
for ($i=0; $i -lt 18; $i++) {
  & gh workflow run 'v2-real-production-test.yml' --repo $Repo --ref main
  if ($LASTEXITCODE -eq 0) { $Started=$true; break }
  Start-Sleep -Seconds 5
}
if (-not $Started) { throw "Repo created but workflow did not start. Open https://github.com/$Repo/actions" }
Write-Host "V2-ONLY RENDER REQUEST SUBMITTED: https://github.com/$Repo/actions" -ForegroundColor Green
Write-Host 'Preflight 44 camera rigs, Edge TTS, 39 stills, 1 full-res benchmark; 3 Blender CPU jobs; final MP4 artifact.'
Write-Host 'Artifact: V2-ep03-real-3D-test-11s (155-second full episode is NOT rendered).'
