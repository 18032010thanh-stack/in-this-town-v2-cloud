"""rt_story.py — V2: đọc stories/epNN.json rồi tự dựng cảnh, thay cho việc viết tay
154 hàm Python mỗi tập như V1.

API giống hệt V1, nên rt_render.py / make.py không phải sửa:
    import rt_story
    build, reset, SHOTS = rt_story.driver("stories/ep01.json")
"""
import json
import math
import os

import bpy
from mathutils import Vector
import rt_engine as E
import rt_cam
import rt_rigs
import rt_sets

# 8 preset mặt của ta -> 16 mặt có sẵn trong rt_faces.py
FACE = {"smile": "happy", "shock": "shock", "sad": "c_tired", "tired": "sleepy",
        "tuc": "stern", "worry": "scared", "calm": "smug", "normal": "smug"}

CAST_LOOK = {
    "Bo":     dict(shirt=(226, 226, 232), pants=(58, 62, 120), hair=("spiky", (30, 30, 36))),
    "Bin":    dict(shirt=(190, 60, 56), pants=(60, 66, 96), hair=("short", (44, 30, 26))),
    "Ba":     dict(shirt=(120, 124, 132), pants=(70, 78, 100), hair=("short", (28, 26, 26))),
    "Me":     dict(shirt=(196, 120, 132), pants=(60, 64, 84), hair=("long", (34, 26, 30))),
    "Ong":    dict(shirt=(132, 104, 76), pants=(70, 62, 52), hair=("short", (214, 210, 206))),
    "CoGiao": dict(shirt=(96, 132, 186), pants=(40, 46, 78), hair=("bun", (36, 28, 26))),
    "BacTu":  dict(shirt=(212, 196, 160), pants=(80, 74, 62), hair=("short", (60, 46, 34))),
}

CROWD_LOOK = [
    ((150, 40, 44), (40, 44, 60), "short", (36, 28, 24)), ((60, 110, 80), (70, 60, 52), "bun", (196, 150, 70)),
    ((210, 130, 50), (44, 50, 80), "long", (120, 44, 36)), ((90, 70, 150), (28, 28, 34), "spiky", (24, 24, 30)),
    ((220, 220, 224), (50, 80, 130), "bun", (60, 40, 30)), ((60, 120, 170), (80, 80, 90), "long", (214, 190, 110)),
    ((180, 150, 60), (46, 40, 60), "short", (90, 60, 40)), ((110, 90, 130), (60, 70, 60), "long", (40, 30, 30)),
]


class Ctx:
    pass


def _seed(name, mod=97):
    """Seed tất định: hash() của Python đổi theo PYTHONHASHSEED, làm chiều cao nhân vật
    thay đổi mỗi lần chạy (đo được 6,05–6,17 stud) và làm sai mọi con số bố cục."""
    h = 0
    for i, c in enumerate(name):
        h = (h * 131 + ord(c) * (i + 7)) % 1000003
    return h % mod


def _mk_char(name):
    look = CAST_LOOK.get(name)
    if look:
        ch = E.Char(name, look["shirt"], look["pants"])
        ch.hair(look["hair"][0], look["hair"][1], seed=_seed(name))
        return ch
    i = _seed(name, len(CROWD_LOOK))
    shirt, pants, style, hair = CROWD_LOOK[i]
    ch = E.Char(name, shirt, pants, scale=0.94 + 0.06 * (i % 2))
    ch.hair(style, hair, seed=i + 10)
    return ch


def driver(json_path):
    story = json.load(open(json_path, encoding="utf-8"))
    shots = story["shots"]
    sides = []
    for s in shots:
        if s.get("set") and s["set"] not in sides:
            sides.append(s["set"])

    def build():
        C = Ctx()
        C.sets = rt_sets.build(only=sides)
        C.chars = {}
        need = set()
        for s in shots:
            for who in (s.get("cast") or ""):
                pass
            need.update((s.get("cast") or {}).keys())
        for who in sorted(need):
            C.chars[who] = _mk_char(who)
        C.crowd = [_mk_char("crowd%d" % i) for i in range(8)]
        C.sides = sides
        return C

    def reset(C):
        pass

    def make_shot(s):
        anchor = s["anchor"]
        zone = anchor.split("_")[0].lower()
        cast = s.get("cast") or {}
        exp = s.get("exp") or {}
        crowd_n = int(s.get("crowd") or 0)

        def shot_fn(C, t, T):
            E.mood(s.get("mood") or "day")
            on = [zone] + list(cast.keys()) + (["crowd%d" % i for i in range(crowd_n)] if crowd_n else [])
            E.use(*on)
            cam_pos = rt_rigs.RIGS[anchor]["pos"]
            for who, mk in cast.items():
                ch = C.chars.get(who)
                if not ch:
                    continue
                x, y, z = rt_rigs.mark_pos(mk)
                yaw = rt_rigs.face_camera(cam_pos, (x, y, z))
                ch.at(x, y, z, yaw=yaw)
                face = FACE.get((exp.get(who) or "normal").lower(), "smug")
                ch.face(face)
                bob = 0.06 * math.sin((t + _seed(who, 7)) * 3.4) * (1.0 if T > 0.3 else 0.0)
                ch.pose(bob=bob)
            for i in range(crowd_n):
                ch = C.crowd[i]
                ang = i * (2 * math.pi / max(1, crowd_n))
                x = math.cos(ang) * 7.0
                y = math.sin(ang) * 5.0 - 4.0
                ch.at(x, y, 0.0, yaw=rt_rigs.face_camera(cam_pos, (x, y, 0.0)))
                ch.face("smug" if i % 2 else "happy")
                ch.pose(bob=0.05 * math.sin(t * 3.1 + i))
            rt_cam.apply(s, t, T)
        return shot_fn

    SHOTS = {}
    for s in shots:
        SHOTS[s["id"]] = make_shot(s)
    return build, reset, SHOTS
