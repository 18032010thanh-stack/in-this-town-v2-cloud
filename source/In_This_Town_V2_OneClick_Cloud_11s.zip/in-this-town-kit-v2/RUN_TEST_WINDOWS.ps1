# Production-quality sample based ONLY on in-this-town-kit-v2.zip.
# This script runs real Blender frames and online Vietnamese Edge TTS, no fake preview.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not $env:BLENDER) {
    $env:BLENDER = 'C:\Program Files\Blender Foundation\Blender 5.2\blender.exe'
}
if (-not (Test-Path $env:BLENDER)) {
    throw 'Blender not found. Set BLENDER to the full path of blender.exe.'
}
$env:RT_ENGINE = 'CYCLES'
python -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependencies installation failed' }
python tools/v2_audit_all.py
if ($LASTEXITCODE -ne 0) { throw '64-file audit failed' }
python verify.py --strict
if ($LASTEXITCODE -ne 0) { throw 'V2 verification failed' }
python tools/audit_numbers.py
if ($LASTEXITCODE -ne 0) { throw 'V2 audit failed' }
foreach ($stage in @('prepare','voice','textures','stills','render','finish')) {
    Write-Host "======= V2 real production stage: $stage ======="
    python tools/v2_preview_production.py $stage
    if ($LASTEXITCODE -ne 0) { throw "V2 stage $stage failed" }
}
Write-Host "REAL MP4: ..\_runtime_v2\build\FINAL.mp4"
Write-Host "VIETNAMESE SRT: ..\_runtime_v2\build\test_v2_vietsub.srt"
