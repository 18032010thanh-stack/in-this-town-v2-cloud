# V2 only — cloud execution in a NEW private repository

This package intentionally contains no footage, characters, code, or story from V1. It includes all **64 original V2 files** with their unchanged hashes. The sample project uses episode 03 shots `s001`–`s013` from V2, for a genuine **11.87-second** Blender 3D production test at **1080 × 1920, 24 FPS**, Vietnamese `vi-VN-NamMinhNeural` Edge TTS, and word-level subtitles.

## Automated setup (Windows)

1. Install **Git for Windows** and **GitHub CLI** if not present. Open a PowerShell terminal inside this extracted `in-this-town-kit-v2` folder.
2. Run `powershell -ExecutionPolicy Bypass -File .\START_V2_CLOUD_PRIVATE.ps1`. Read the script first if you want to inspect GitHub actions and repository permissions.
3. Sign in via GitHub in your browser if asked. No access token needs to be shared with ChatGPT.
4. The script verifies the SHA-256 values of every original V2 source file, creates **a NEW PRIVATE repo** named `in-this-town-kit-v2-cloud`, pushes the complete package, and asks you to approve the real test run before submitting it.
5. GitHub Actions → `V2 ONLY - real 3D production test (11.87s)` → artifact `V2-ep03-real-3D-test-11s` should contain the final MP4 **only if all stages genuinely succeed**.

The script **refuses to overwrite existing GitHub repositories or any folder containing `.git`**. Existing V1 project remains untouched. Rendering runs on GitHub, not on the local machine.

## Tests and limits

`python -m unittest discover -s tests -v` runs the static tests. `python verify.py --strict` and `python tools/audit_numbers.py` validate the original source. The full workflow performs frame/camera checks on Blender, real Edge TTS (internet required), image-texture generation, 13 × 3 preview stills, 285 production frames, and FFmpeg/H.264-AAC verification.

The original V2 ZIP did not include a redistributable license. Keep the repo PRIVATE unless you own the content and confirm licensing. GitHub-hosted private Actions have usage quotas; a 240-minute timeout is a ceiling, **not** an estimated render time. Do not claim a rendered MP4 exists before the final artifact has been inspected.
