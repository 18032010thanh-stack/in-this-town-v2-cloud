# V2 Production Test — dùng **duy nhất** ZIP V2

> **Đây là một bộ chạy thử thực tế, chưa phải MP4 đã render.** Không dùng bất cứ kịch bản, footage, âm thanh hoặc code do AI tự chế trước đây; không sửa V1. Bộ source V2 gốc 64 tệp vẫn nguyên byte, được đối chiếu bằng `V2-SOURCE-MANIFEST.json`.

## Đoạn mẫu đã chọn

- **Nguồn:** `stories/ep03.json` — *Tập 3: Số Trên Đầu*.
- **Cảnh:** s001…s013, 13 scene V2 nguyên văn; từ phố → công viên → lớp học. Không tái sáng tác cốt truyện.
- **Thời lượng đúng theo dữ liệu V2:** **11,87 giây**.
- **Chất lượng đích:** 1080 × 1920, 24 FPS, Blender 3D theo `rt_engine`, 3 bộ bối cảnh, dữ liệu camera của `rt_rigs` và chuyển động `rt_cam`.
- **Tiếng Việt:** `vi-VN-NamMinhNeural` từ `rt_voice.py` (Edge TTS cần mạng), phụ đề karaoke từng từ vẽ bằng **chính `rt_finish.py`**, kèm file `.srt` nguyên lời V2.
- **Không** nhạc, sound effect, Roblox models hay dữ liệu phim V1. Quy trình bốn bước V2 vẫn giữ: giọng → texture → Blender → finish.

## Điều đã đo, không phải phỏng đoán

- ZIP V2 chứa **64/64 tệp**, mở và kiểm SHA256 đầy đủ.
- `python verify.py --strict`: **14/14 PASS**.
- `python tools/audit_numbers.py`: **44/44 PASS** (tool in ra 44 phép).
- Cả **28 file Python**, **11 file JSON**, **10 file SRT**, **8 texture PNG**, và **7 tài liệu/cấu hình** đã được phân tích/giải mã. Danh mục và hash chi tiết nằm trong `V2-COMPLETE-REVIEW.md`.
- Mốc cảnh có lỗi logic ở `rt_render.py` gốc: một cảnh rỗng lời có thể làm cảnh có lời ngay trước đó bằng 0 frame. Bản test sinh riêng `/../_runtime_v2/rt_render.py` với thuật toán phân phối khoảng thời gian cho tất cả shot. **Không sửa mã gốc V2**.
- Bản test sinh riêng `/../_runtime_v2/rt_engine.py` để cập nhật Cycles denoise API khi Blender có khác biệt. Không thay API cảnh.
- `prepare` đã đạt: **13/13 cảnh có khoảng hiển thị >0**, 8/8 texture PNG giải mã được.

## Test ngay trên Cloud bằng chính mã V2

Thực hiện trên **repo private hoặc môi trường được phép** để không công khai cả kit khi quyền phát hành chưa rõ. Copy toàn bộ nội dung thư mục này vào **gốc** repo riêng của V2 (không đưa lên main V1). Chạy GitHub Actions → `V2 ONLY - real 3D production test (11.87s)` → `Run workflow`. Workflow sẽ:

1. Cài Blender/FFmpeg và đúng `requirements.txt` V2.
2. Chạy kiểm toán 64 tệp + 14/14 verify + 44/44 audit.
3. Chạy `tools/framing_check.py` trên Blender: kiểm tra 44 rigs và 1516 cảnh thật của V2 (không lấy các cảnh đó làm kịch bản test).
4. Dùng giọng nói Việt Edge TTS **thật**, sinh lại 8 texture bằng Skia, render 3 still × 13 cảnh + sheet xem khung hình.
5. Render đủ 285 khung hình bằng Blender 3D ở 1080×1920. Hậu kỳ chính V2 với màu, glow, vignette, từng từ hiện vàng, âm thanh và H.264/AAC.
6. Kiểm tra FFprobe: **không thiếu frame**, kích thước 1080×1920, 24 FPS, có H.264 + AAC và độ dài khớp 11,87s; tải artifact `V2-ep03-real-3D-test-11s`.

**Thận trọng:** V2 tài liệu nhắm Blender 5.2, còn runner GitHub có thể có phiên bản khác. Workflow kiểm phiên bản rồi dừng khi lỗi thay vì ngụy tạo kết quả. Render ở độ phân giải production với CPU có thể tốn nhiều thời gian; job được giới hạn ở 240 phút, không chạy tự động khi push. Nếu thiếu Edge TTS hoặc không có Internet, bước voice thất bại và không có video giả.

## Lệnh chạy cục bộ (máy đã có Blender 5.x, Python, FFmpeg, Internet)

```bash
python -m pip install -r requirements.txt
python tools/v2_audit_all.py
python verify.py --strict
python tools/audit_numbers.py
python tools/v2_preview_production.py prepare
python tools/v2_preview_production.py voice
python tools/v2_preview_production.py textures
python tools/v2_preview_production.py stills
python tools/v2_preview_production.py render
python tools/v2_preview_production.py finish
```

Tệp đầu ra nằm ở **thư mục runtime riêng** kế bên V2 kit: `../_runtime_v2/build/FINAL.mp4`, `../_runtime_v2/build/test_v2_vietsub.srt` và `../_runtime_v2/build/stills/_sheet*.jpg`.

## Những điểm **chưa** chứng minh trong môi trường ChatGPT này

- Không có lệnh `blender`, không có package `bpy` và không thể tải Blender qua Internet. **Chưa render được 1 frame thật ở đây**.
- Không thể liên hệ Edge TTS, chưa tạo được `vo.wav`/`words.json` thật.
- Không thể chạy `framing_check.py` bằng Blender hay xem phim sau render để đánh giá chuyển động/khung hình thực tế.

Vì vậy **không gọi bộ nguồn này là phim MP4 hoàn chỉnh**. Chỉ ghi đạt sau khi có video + logs + artifact thực sự.

## Lưu ý pháp lý

- ZIP V2 **không có LICENSE** xác nhận quyền xuất bản source. Không upload công khai nếu chưa xác nhận quyền.
- Mẫu sử dụng đúng các đoạn có trong V2 người dùng tải lên. Không lắp nội dung, nhân vật hoặc âm thanh từ V1 hay bất kỳ video cũ nào.
- Tài liệu gốc nêu không liên kết chính thức với Roblox; không được tự tuyên bố đây là nội dung Roblox có cấp phép.
- Giọng Edge TTS miễn phí cho thử nghiệm không đồng nghĩa tự động có mọi quyền sử dụng thương mại. Nếu xuất bản thương mại, nên dùng giọng bạn thu hoặc dịch vụ có điều khoản cấp phép rõ.
