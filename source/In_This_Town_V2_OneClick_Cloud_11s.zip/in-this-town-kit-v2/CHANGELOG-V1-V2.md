# V1 → V2: đổi những gì

Mọi số dưới đây đo bằng `python tools/audit_numbers.py` (45/45 PASS) và `python verify.py` (14/14 PASS) trên chính cây này.

## 1. Số liệu

| | V1 (`in-this-town-kit.zip`) | V2 |
|---|---|---|
| File | 14 | 61 (kèm 8 texture mặt) |
| Story | 1 mẫu: 17 cảnh / 20 s | **10 tập: 1516 cảnh / 1495,8 s** |
| Câu thoại | 1 mẫu | **715 câu** |
| Bối cảnh | 2 (`Street`, `Room`) | **8** (`street, hall, class, park, shop, kitchen, bedroom, cellar`) |
| Camera | đặt tay trong từng hàm cảnh | **44 rig** + 8 cú máy |
| Mark đặt diễn viên | không có | **24 mark** (8 khu × 3) |
| Mood | 6 | 6 (giữ nguyên) |
| Chiều cao nhân vật | không cố định (hash đổi theo phiên) | **6,033 stud**, seed tất định |
| Mặt | 16 | 16 (giữ nguyên, `rt_faces.py` không đổi) |
| Nhịp | 24 fps | 24 fps |
| Kiểm tra | không có | `verify.py` 14 phép + `tools/audit_numbers.py` 45 phép + `tools/framing_check.py` (bố cục, có raycast) |

Từng tập (đo từ `stories/epNN.json`):

| Tập | Cảnh | Giây | s/cảnh |
|---|---|---|---|
| 1 Đọc Ý Đồ | 154 | 148,5 | 0,96 |
| 2 Bóng Rời Chân | 151 | 152,7 | 1,01 |
| 3 Số Trên Đầu | 156 | 155,5 | 1,00 |
| 4 Loa Phường | 145 | 144,8 | 1,00 |
| 5 Cái Cân Chợ | 147 | 142,2 | 0,97 |
| 6 Ghế Đá | 151 | 148,6 | 0,98 |
| 7 Bảng Đen | 150 | 147,2 | 0,98 |
| 8 Cửa Nhà | 146 | 145,1 | 0,99 |
| 9 Đồng Hồ Ngược | 155 | 151,7 | 0,98 |
| 10 Ảnh Gia Đình | 161 | 159,4 | 0,99 |

Tỉ lệ trên 1516 cảnh: push-in **60%**, dutch **19%**, vệt luật **93%**.

## 2. File thêm

| File | Việc |
|---|---|
| `rt_sets.py` | 8 bối cảnh dựng bằng khối. Mặt đường/z-fighting lấy từ `rt_engine.Street` (dòng 516–518): cỏ 0,00 · nhựa đường 0,05 · vạch 0,09 · vỉa hè 0,25 — không lớp nào trùng cao độ |
| `rt_rigs.py` | 44 rig, 24 mark, `mark_pos()`, `face_camera()`; không import `bpy` nên kiểm được ngoài Blender |
| `rt_cam.py` | 8 cú máy + rung tay nhẹ; sửa góc dọc (Blender hiểu `angle` là góc ngang → trước khi sửa mọi cảnh bị chặt ~1,5 lần) |
| `rt_story.py` | đọc JSON → dựng cảnh; map 8 biểu cảm → 16 mặt; `_clear_cameras()` raycast đẩy camera ra khỏi vật cản |
| `verify.py` | 14 phép kiểm số liệu, chạy không cần Blender |
| `tools/make_stories.py` | CSV đã đo → `stories/epNN.json`; **không sinh lại số** |
| `tools/audit_numbers.py` | đối chiếu số trong tài liệu với số thật (45 phép) |
| `stories/ep01..10.json` + `.py` | 10 tập; `.py` chỉ là shim gọi `rt_story.driver()` |
| `data/ep01..10-subs.srt` | phụ đề 10 tập (mốc chữ do `rt_voice.py` sinh ra khi chạy) |
| `V2-MAP.md` | bảng kiến trúc: số nào do file nào sinh |
| `CHANGELOG-V1-V2.md` | file này |

## 3. File V1 bị sửa (giữ API, chỉ vá lỗi)

| File | Sửa gì | Vì sao |
|---|---|---|
| `rt_render.py` | `shot_times()` chia thời gian cho cảnh **không có thoại** theo `dur` | V2 có 2 cảnh/câu; cảnh thứ 2 rỗng lời → V1 sẽ cho nó 0 giây |
| `rt_finish.py` | danh sách font dự phòng + biến `CAPTION_FONT` | V1 cứng `C:\Windows\Fonts\seguibl.ttf`, Cloud là Linux → không có font, phụ đề mất |
| `rt_engine.py` | đọc `RT_ENGINE`: `CYCLES` (CPU, chia đôi samples, bật denoise) hoặc EEVEE mặc định; các dòng `ee.*` bọc `if ee is not None` | máy không GPU: EEVEE crash `EXCEPTION_ACCESS_VIOLATION` |

Không đổi: `make.py`, `rt_voice.py`, `rt_faces.py`, `rt_sheet.py`, `Char`/`Street`/`Room`/`mood`/`cam`.

## 4. Đã chạy thật, chưa chạy thật

Đã chạy: `verify.py` 14/14, `audit_numbers.py` 45/45, dựng cảnh 10 tập (2,0–2,4 s/tập), render 6 khung still bằng `RT_ENGINE=CYCLES` (50–113 s cho 3 khung ở 20–25% độ phân giải).

Chưa chạy: **render trọn một tập**, **thu giọng thật** (`build/words.json` hiện là mốc thời gian giả lập), **ghép mp4 có phụ đề**. Ba việc này cần máy nhanh / mạng → làm trên Cloud.

Đã sửa bố cục và **đo lại bằng máy**: `tools/framing_check.py` cho **44/44 rig PASS** và
**1516/1516 cảnh thật đạt**. Phép kiểm gồm 3 phần: chiếu đầu/chân ra toạ độ khung, bắn 6 hướng
để phát hiện "camera nằm trong vật đặc", và raycast camera → ngực nhân vật để tìm vật chắn
(cảnh lia máy chấm bằng dải gộp của hai rig; mỗi cảnh đo ở 5% / 50% / 95% thời lượng để bắt cú máy đâm vào hình học giữa cảnh; 0 cảnh bí chỗ đặt camera). Chi tiết công thức, bảng dải và các con số sửa
trong `V2-MAP.md` §5.

Còn lại: chưa duyệt bằng mắt từng cảnh (máy này 30–60 s/khung), chưa render trọn tập, chưa thu giọng.
