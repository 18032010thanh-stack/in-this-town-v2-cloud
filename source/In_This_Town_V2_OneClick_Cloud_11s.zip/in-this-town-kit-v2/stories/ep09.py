"""V2: mọi cảnh lấy từ ep09.json, không viết tay hàm nào."""
import os
import rt_story

_J = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ep09.json')
build, reset, SHOTS = rt_story.driver(_J)
