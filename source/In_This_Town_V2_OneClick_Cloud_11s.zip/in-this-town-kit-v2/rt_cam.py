"""rt_cam.py — đặt camera thật trong Blender, dùng rig của rt_rigs.py.

Ba việc, theo thứ tự, mỗi cảnh:

1. Lấy rig gốc (vị trí, điểm ngắm, fov) rồi **hiệu chỉnh cỡ cảnh có giới hạn** quanh rig:
   CSV có fov 30 hay 62 thì ống kính chỉ được phép lệch `rig_fov − 12 … + 8`, và khoảng cách
   chỉ được chỉnh trong `0,60 … 1,30` lần rig. Nhờ vậy `frac` (chiều cao nhân vật / chiều cao
   khung) bám mục tiêu của kiểu rig mà không phá cú máy.
2. Chạy cú máy (`to`, push, snap, orbit, crane, whip, rung tay) **trên rig đã hiệu chỉnh** —
   hiệu chỉnh không được đè lên chuyển động.
3. Kẹp camera vào vùng đi lại được của khu (không lọt vào tường nhà, không ra ngoài phòng).

Lưu ý Blender: `camera.data.angle` là góc NGANG; khung của ta là dọc 1080×1920,
nên ống kính được đặt lại theo góc dọc: lens = (sensor_height/2) / tan(fov/2).
"""
import math

import bpy
import rt_engine as E
from rt_rigs import (RIGS, KIND, INTERIOR_SCALE, BODY, ZONE, ORIGIN, LIMIT,
                     mark_pos, face_camera)

FOV_DOWN = 12.0        # cho phép hẹp hơn rig bao nhiêu độ
FOV_UP = 8.0           # cho phép rộng hơn rig bao nhiêu độ
DIST_LO = 0.60         # chỉnh khoảng cách tối đa 40% về phía trước (rig cận cần tiến)
DIST_HI = 1.30         # ... và 30% về phía sau


CAST_PREFIX = ("Bo", "Bin", "Ba", "Me", "Ong", "CoGiao", "BacTu") + tuple("crowd%d" % i for i in range(8))
_AXES = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]
UNRESOLVED = []                      # những cảnh không tìm được chỗ đặt camera sạch


def _hit_count(pos, tgt):
    """Số mặt bị cắt từ camera tới ngực nhân vật (bỏ qua chính nhân vật)."""
    scene = bpy.context.scene
    dg = bpy.context.evaluated_depsgraph_get()
    from mathutils import Vector
    d = Vector(tgt) - Vector(pos)
    L = d.length
    if L < 1e-3:
        return 0
    hit, loc, nor, idx, obj, mat = scene.ray_cast(dg, Vector(pos), d.normalized(), distance=L * 0.97)
    if not hit:
        return 0
    return 0 if obj.name.split("_")[0] in CAST_PREFIX else 1


def _inside(pos):
    """Camera nằm trong vật đặc: 6 hướng đều đụng mặt kín trong 0,25 stud."""
    scene = bpy.context.scene
    dg = bpy.context.evaluated_depsgraph_get()
    from mathutils import Vector
    n = 0
    for a in _AXES:
        if scene.ray_cast(dg, Vector(pos), Vector(a), distance=0.25)[0]:
            n += 1
    return n == 6


def _resolve(pos, tgt, tag=""):
    """Đặt camera ở chỗ KHÔNG nằm trong vật đặc và KHÔNG bị chắn. Thử lần lượt vài vị trí."""
    cands = [list(pos)]
    for dz in (0.8, 1.6):
        cands.append([pos[0], pos[1], pos[2] + dz])
    for dx in (2.0, -2.0, 4.0, -4.0):
        cands.append([pos[0] + dx, pos[1], pos[2]])
    for dy in (1.2, 2.4):
        cands.append([pos[0], pos[1] + dy, pos[2]])
    cands.append([pos[0], pos[1] - 1.2, pos[2]])
    for c in cands:
        if not _inside(c) and _hit_count(c, tgt) == 0:
            return c
    UNRESOLVED.append(tag)
    return list(pos)


def _base(rig, fov):
    """Vị trí/điểm ngắm của rig sau khi hiệu chỉnh cỡ cảnh, giới hạn ±(15–20)%."""
    pos = list(rig["pos"])
    tgt = list(rig["tgt"])
    kind = rig.get("kind")
    if not kind or kind == "SIGN":
        return pos, tgt
    scale = INTERIOR_SCALE if rig["zone"] not in ("street", "park") else 1.0
    frac = KIND[kind]["frac"] * scale
    d_need = (BODY / frac) / (2.0 * math.tan(math.radians(fov) / 2.0))
    vx, vy, vz = pos[0] - tgt[0], pos[1] - tgt[1], pos[2] - tgt[2]
    d_rig = math.sqrt(vx * vx + vy * vy + vz * vz)
    if d_rig < 1e-3:
        return pos, tgt
    f = min(DIST_HI, max(DIST_LO, d_need / d_rig))
    if abs(f - 1.0) < 1e-3:
        return pos, tgt
    horiz = math.hypot(vx, vy)
    need_h = math.sqrt(max((d_rig * f) ** 2 - vz * vz, 1.0))
    if horiz > 1e-3 and need_h >= 2.0:
        k = need_h / horiz                                  # giữ nguyên cao độ camera
        return [tgt[0] + vx * k, tgt[1] + vy * k, pos[2]], tgt
    k = f                                                   # rig chúc lên/xuống: co cả hướng
    return [tgt[0] + vx * k, tgt[1] + vy * k, max(0.4, tgt[2] + vz * k)], tgt


def apply(shot, t, T):
    """Đặt camera cho một cảnh. `t` = giây từ đầu cảnh, `T` = độ dài cảnh."""
    a = RIGS[shot["anchor"]]
    b = RIGS[shot["to"]] if shot.get("to") else None
    fov0 = float(shot.get("fov") or a["fov"])
    fov1 = float(shot.get("fovTo") or fov0)
    fov0 = min(max(fov0, a["fov"] - FOV_DOWN), a["fov"] + FOV_UP)
    fov1 = min(max(fov1, a["fov"] - FOV_DOWN), a["fov"] + FOV_UP)
    roll = float(shot.get("dutch") or 0.0) + a["roll"]
    p = min(1.0, max(0.0, t / max(1e-6, T)))
    move = (shot.get("move") or "").lower()

    pos, tgt = _base(a, fov0)
    if b is not None:
        pos_b, tgt_b = _base(b, fov1)
        q = p * p * (3 - 2 * p)
        pos = [pos[i] + (pos_b[i] - pos[i]) * q for i in range(3)]
        tgt = [tgt[i] + (tgt_b[i] - tgt[i]) * q for i in range(3)]
        fov0 = fov0 + (fov1 - fov0) * q
    elif fov1 != fov0 or move in ("push", "snap"):
        q = p if move != "snap" else min(1.0, p * 3.0)
        q = q * q * (3 - 2 * q)
        dolly = 0.22 if move == "snap" else 0.10
        pos = [pos[i] + (tgt[i] - pos[i]) * dolly * q for i in range(3)]
        fov0 = fov0 + (fov1 - fov0) * q

    if move == "orbit":
        ang = math.radians(14.0) * (2 * p - 1)
        dx, dy = pos[0] - tgt[0], pos[1] - tgt[1]
        pos[0] = tgt[0] + dx * math.cos(ang) - dy * math.sin(ang)
        pos[1] = tgt[1] + dx * math.sin(ang) + dy * math.cos(ang)
    elif move == "crane":
        pos[2] += 2.4 * p
    elif move == "whip":
        q = min(1.0, p / 0.28)
        pos[0] += 3.0 * (1 - q)
        roll += 6.0 * (1 - q)
    elif move in ("", "hold", "push") and T > 0.4:
        pos[0] += 0.035 * math.sin(t * 5.1)
        pos[2] += 0.025 * math.sin(t * 6.7 + 1.0)

    # 3. camera phải nằm trong vùng đi lại được của khu
    zone = a["zone"]
    ox, oy, oz = ORIGIN[zone]
    w, d = ZONE[zone]
    lim_x, lim_y = w / 2.0 - 1.5, d / 2.0 - 1.5
    if zone in LIMIT:
        lim_x = min(lim_x, LIMIT[zone][0])
        lim_y = min(lim_y, LIMIT[zone][1])
    pos = [ox + max(-lim_x, min(lim_x, pos[0] - ox)),
           oy + max(-lim_y, min(lim_y, pos[1] - oy)), pos[2]]

    pos = _resolve(pos, tgt, tag=shot.get("id") or shot.get("anchor"))
    E.cam(tuple(pos), tuple(tgt), fov0, roll)
    cam = E.G.cam
    cam.data.sensor_fit = "VERTICAL"
    cam.data.lens = (cam.data.sensor_height / 2.0) / math.tan(math.radians(fov0) / 2.0)
