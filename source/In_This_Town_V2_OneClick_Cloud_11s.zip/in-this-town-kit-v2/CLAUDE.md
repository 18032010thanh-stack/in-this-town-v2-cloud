@AGENTS.md

Follow AGENTS.md in this folder. README.md explains every file.
