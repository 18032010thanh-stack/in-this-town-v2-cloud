#!/usr/bin/env python3
"""Exhaustive, reproducible inspection of all 64 files in uploaded V2.

Does NOT import or use any previous/legacy video or V1 package. Reads only the
byte-identical V2 ZIP members captured in V2-SOURCE-MANIFEST.json.
"""
from pathlib import Path
from collections import Counter
import ast, hashlib, json, re, subprocess, sys
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
MANIFEST=json.loads((ROOT/'V2-SOURCE-MANIFEST.json').read_text(encoding='utf-8'))['source_files']
REPORT=ROOT/'V2-COMPLETE-REVIEW.md'
LINES=['# Kiểm toán 100% nội dung bộ `in-this-town-kit-v2.zip`','',
       '> Chỉ đọc trực tiếp 64 tệp nằm trong ZIP V2 người dùng tải lên; không đọc, import hoặc tái sử dụng bản V1 hay video/kịch bản cũ. Hai tệp ví dụ legacy có trong ZIP V2 chỉ được kiểm tra tính hợp lệ, không được lấy làm nguồn cho bản test.', '',
       '## Tổng quan', '']

json_count=py_count=srt_count=png_count=other=0
errors=[]
py_entries=[]
images=[]
srt_entries=[]
json_entries=[]
text_entries=[]
for name,meta in MANIFEST.items():
    p=ROOT/name
    if not p.is_file():errors.append('MISSING '+name);continue
    raw=p.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=meta['sha256']:
        errors.append('MODIFIED '+name)
    suffix=p.suffix.lower()
    if suffix=='.py':
        py_count+=1
        try:
            t=ast.parse(raw)
            fns=[n.name for n in t.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))]
            imps=[]
            for n in t.body:
                if isinstance(n,ast.Import):imps.extend(a.name for a in n.names)
                elif isinstance(n,ast.ImportFrom):imps.append(n.module or '?')
            py_entries.append((name,len(raw),len(fns),', '.join(fns[:5]),', '.join(imps[:10])))
        except Exception as e:errors.append(f'PY parse {name}: {e}')
    elif suffix=='.json':
        json_count+=1
        try:
            obj=json.loads(raw)
            json_entries.append((name,len(obj.get('shots',[])),obj.get('seconds','—'),obj.get('voice','—')))
        except Exception as e:errors.append(f'JSON parse {name}: {e}')
    elif suffix=='.srt':
        srt_count+=1
        s=raw.decode('utf-8-sig')
        cues=re.findall(r'(?m)^(\d+)\s*\n(\d\d:\d\d:\d\d,\d\d\d)\s*-->\s*(\d\d:\d\d:\d\d,\d\d\d)\s*\n(.+)$',s)
        if not cues:errors.append('SRT empty '+name)
        ids=[int(x[0]) for x in cues]
        if ids!=list(range(1,len(ids)+1)):errors.append('SRT cue numbering '+name)
        def to_ms(st):
            h,mi,se,ms=map(int,re.split('[:,]',st));return ((h*60+mi)*60+se)*1000+ms
        if any(to_ms(e)<=to_ms(a) for _,a,e,_ in cues):errors.append('Invalid subtitle interval '+name)
        srt_entries.append((name,len(cues),cues[-1][2] if cues else '—'))
    elif suffix=='.png':
        png_count+=1
        try:
            with Image.open(p) as im:
                wh=im.size;mode=im.mode;im.verify()
                images.append((name,wh,mode))
        except Exception as e:errors.append(f'PNG corrupted {name}: {e}')
    else:
        other+=1
        try:
            s=raw.decode('utf-8-sig')
            if not s.strip():errors.append('EMPTY '+name)
            text_entries.append((name,len(s.splitlines()),len(raw)))
        except UnicodeError:errors.append('UNREADABLE TEXT '+name)

LINES.append(f'- Đã mở và xác thực SHA-256: **{len(MANIFEST)}/64 tệp**.')
LINES.append(f'- Python: **{py_count}**, JSON: **{json_count}**, SRT: **{srt_count}**, PNG: **{png_count}**, tài liệu/khác: **{other}**.')
LINES.append(f'- Tệp lỗi dữ liệu/giải mã: **{len(errors)}**.')
LINES.append('- `tools/_codex/rig_probe.py` và `measure_stills.py` có BOM UTF-8, parser Python đọc được; không phải lỗi file.')
LINES.append('')
LINES.append('## Chỉ số tập V2 đã kiểm tra')
LINES.append('')
LINES.append('| Tập | Cảnh | Giây | Lời thoại | Bộ bối cảnh |')
LINES.append('|---|---:|---:|---:|---|')
for n in range(1,11):
    story=json.loads((ROOT/f'stories/ep{n:02}.json').read_text(encoding='utf-8'))
    scenes=story['shots']; sets=sorted(set(s['set'] for s in scenes))
    LINES.append(f"| {n} — {story['title']} | {len(scenes)} | {story['seconds']} | {sum(bool(s['line']) for s in scenes)} | {', '.join(sets)} |")
LINES.append('')
LINES.append('## Kết quả đối chiếu phụ đề V2')
LINES.append('')
LINES.append('| Tệp | Câu phụ đề | Cue cuối |')
LINES.append('|---|---:|---|')
for row in srt_entries:LINES.append('| '+ ' | '.join(map(str,row))+' |')
LINES.append('')
LINES.append('## Toàn bộ texture V2')
LINES.append('')
LINES.append('| File | Kích thước | Mode |')
LINES.append('|---|---|---|')
for name,wh,mode in images:LINES.append(f'| `{name}` | {wh[0]}×{wh[1]} | {mode} |')
LINES.append('')
LINES.append('## Tất cả file Python V2: đã đọc và phân tích AST')
LINES.append('')
LINES.append('| Tệp | Bytes | Hàm/lớp top-level | Hàm/lớp đại diện | Import đại diện |')
LINES.append('|---|---:|---:|---|---|')
for name,nb,nf,functions,imports in py_entries:
    LINES.append(f'| `{name}` | {nb} | {nf} | {functions} | {imports} |')
LINES.append('')
LINES.append('## Tất cả file JSON V2')
LINES.append('')
for name,n,seconds,voice in json_entries:LINES.append(f'- `{name}`: {n} cảnh, {seconds} s, voice={voice}')
LINES.append('')
LINES.append('## Tất cả file tài liệu/cấu hình V2')
LINES.append('')
for name,lc,bytecount in text_entries:LINES.append(f'- `{name}`: {lc} dòng, {bytecount} bytes — đọc được')
LINES.append('')
LINES.append('## Vấn đề thực tế ảnh hưởng sản xuất')
LINES.append('')
LINES.extend([
'1. **Chưa thể kết luận 1516 cảnh đều hiển thị trong bản xuất**: `rt_render.py/shot_times()` cho cảnh trống lời mốc cắt bằng mốc cảnh trước, khiến nhiều cảnh thoại thành đoạn 0-frame. Tập 3 tái hiện được 69/156 cảnh 0-frame với bộ mốc từ V2 `dur` giả lập; cần kiểm tra lại bằng voice thật và dùng bản vá riêng cho test.',
'2. `make.py --preview` **không phải clip ngắn**, mà vẫn làm cả story ở 50% độ phân giải. Bản test chọn 13 shot gốc, full 1080×1920 24fps, không dùng --preview.',
'3. `rt_render.py` đọc `build/words.json` nên **không có voice thật thì không thể dựng timeline gốc đúng**. Các `data/epNN-subs.srt` không thay thế timestamps word-by-word.',
'4. `rt_finish.py` tái sử dụng frame trước nếu frame thiếu. Bộ test đã bổ sung kiểm tra **không thiếu bất kỳ frame nào** trước khi chạy bước finish.',
'5. CPU Cycles denoise có khác biệt API giữa phiên bản Blender; bản test chỉ vá runtime để dùng `view_layers[].cycles.use_denoising` khi hỗ trợ, không sửa mã V2 gốc.',
'6. Chưa thấy `LICENSE` trong archive V2. **Không khẳng định quyền tái phân phối toàn bộ mã/ảnh lên repo public**; nên dùng workspace/repo private nếu render trên Cloud.',
'7. `rt_voice.py` sử dụng edge-tts online: phải có kết nối mạng và người dùng cần tự xem điều kiện sử dụng trước khi đăng nội dung thương mại; không thay voice bằng âm thanh tự tạo/không đồng bộ.',
'8. Bộ này không có Blender và không truy cập được internet ở môi trường kiểm thử hiện tại; chưa thể chạy `framing_check.py` bằng Blender hoặc xuất MP4 3D thật ngay tại đây.',
])
LINES.append('')
LINES.append('## File kiểm kê đủ 64 tệp V2 (không có ngoại lệ)')
LINES.append('')
LINES.append('| Đường dẫn | Bytes | SHA-256 |')
LINES.append('|---|---:|---|')
for name,meta in MANIFEST.items():LINES.append(f'| `{name}` | {meta["bytes"]} | `{meta["sha256"]}` |')
LINES.append('')
LINES.append('## Lỗi nguồn/kiểm toán')
LINES.append('')
LINES.extend(['- '+x for x in errors] if errors else ['Không có lỗi parse/giải mã/hash trên 64 file gốc.'])
REPORT.write_text('\n'.join(LINES)+'\n',encoding='utf-8')
print('AUDITED 64 source files | Python',py_count,'JSON',json_count,'SRT',srt_count,'PNG',png_count,'OTHER',other,'ERR',len(errors))
print('REPORT',REPORT)
if errors:
    print('\n'.join(errors));sys.exit(1)
