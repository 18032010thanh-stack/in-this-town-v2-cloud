"""tools/framing_check.py — kiểm bố cục bằng số, chạy trong Blender:

    RT_ENGINE=CYCLES blender -b --factory-startup --python tools/framing_check.py

Vòng 1 — 44 rig: đặt camera thật, chiếu đầu/chân nhân vật (cao rt_rigs.BODY stud) ra
toạ độ khung, raycast từ camera tới nhân vật để tìm vật chắn. Đạt khi:
  - chiều cao nhân vật nằm trong dải của đúng kiểu rig (rt_rigs.BAND, đã nhân hệ số trong nhà)
  - với rig rộng: thấy cả đầu và chân; với rig cận/trung: thân người nằm giữa khung
  - không có vật chắn nào giữa camera và nhân vật

Vòng 2 — 1516 cảnh thật trong stories/*.json, dùng đúng fov/move/push của từng cảnh.
Đây mới là con số quyết định, vì CSV đổi fov nên framing khác rig gốc.
"""
import glob
import json
import os
import sys

sys.path.insert(0, os.getcwd())
import bpy
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
import rt_engine as E
import rt_rigs
import rt_cam
import rt_sets

TIGHT = ("C", "M", "LOW", "DARK", "DOOR", "UP", "SIGN", "TOP", "L", "SIDE")

E.new_scene(1080, 1920, 24, 4)
rt_sets.build()
scene = bpy.context.scene


def measure(cam, mk):
    """trả về (frac, foot, head, chest) đã chiếu vào khung."""
    foot = world_to_camera_view(scene, cam, mk)
    head = world_to_camera_view(scene, cam, mk + Vector((0, 0, rt_rigs.BODY)))
    chest = world_to_camera_view(scene, cam, mk + Vector((0, 0, rt_rigs.BODY * 0.55)))
    return abs(head.y - foot.y), foot, head, chest


AXES = [Vector((1, 0, 0)), Vector((-1, 0, 0)), Vector((0, 1, 0)),
        Vector((0, -1, 0)), Vector((0, 0, 1)), Vector((0, 0, -1))]


def inside_solid(cam, r=0.3):
    """Camera nằm TRONG vật đặc: bắn 6 hướng, hết 6 hướng đều đụng mặt trong 0,3 stud.
    (Một tia xuyên qua khối đặc không cắt mặt nào nên raycast thường không phát hiện được.)"""
    dg = bpy.context.evaluated_depsgraph_get()
    hits = 0
    for d in AXES:
        if scene.ray_cast(dg, cam.location.copy(), d, distance=r)[0]:
            hits += 1
    return hits == 6


def blocked(cam, target):
    """Có vật chắn giữa camera và ngực nhân vật không (bỏ qua chính nhân vật)."""
    d = target - cam.location
    L = d.length
    if L < 1e-3:
        return ""
    hit, loc, nor, idx, obj, mat = scene.ray_cast(
        bpy.context.evaluated_depsgraph_get(), cam.location.copy(), d.normalized(), distance=L * 0.97)
    if not hit:
        return ""
    if obj.name.endswith("_root") or "crowd" in obj.name:
        return ""
    return obj.name


def verdict(kind, band, frac, foot, head, chest):
    # frac > 0,85: thân người đã choán khung, cắt mép đầu/chân là bình thường
    if kind in TIGHT or frac > 0.85:
        return (band[0] <= frac <= band[1] and 0.08 <= chest.y <= 0.92
                and abs(chest.x - 0.5) < 0.34)
    return (band[0] <= frac <= band[1] and 0.02 <= foot.y <= 0.98
            and 0.02 <= head.y <= 0.98 and abs(foot.x - 0.5) < 0.30)


# ---------------- vòng 1: 44 rig ----------------
rows = []
ok = 0
for name, rig in rt_rigs.RIGS.items():
    mk = Vector(rt_rigs.mark_pos(rig["zone"].upper() + "_MK1"))
    rt_cam.apply({"anchor": name, "move": "hold"}, 0.0, 1.0)
    bpy.context.view_layer.update()
    cam = E.G.cam
    frac, foot, head, chest = measure(cam, mk)
    chestw = mk + Vector((0, 0, rt_rigs.BODY * 0.55))
    d = chestw - cam.location
    hit, loc, nor, idx, obj, mat = scene.ray_cast(
        bpy.context.evaluated_depsgraph_get(), cam.location, d.normalized(), distance=d.length * 0.97)
    clear = (not hit) or ("crowd" in obj.name) or obj.name.endswith("_root")
    good = verdict(rig["kind"], rig["band"], frac, foot, head, chest) and clear
    ok += 1 if good else 0
    rows.append((name, rig["kind"], (cam.location - mk).length, frac, rig["band"],
                 obj.name if hit else "-", good))
    print("%-13s %-4s dist=%5.1f frac=%4.2f band=%.2f-%.2f obst=%-18s %s" % (
        name, rig["kind"], rows[-1][2], frac, rig["band"][0], rig["band"][1],
        obj.name if hit else "-", "PASS" if good else "FAIL"))

bad = [r[0] for r in rows if not r[-1]]
print("\nRIG: %d/%d PASS" % (ok, len(rows)))
if bad:
    print("  rig hỏng:", ", ".join(bad))

# ---------------- vòng 2: 1516 cảnh thật ----------------
# Mỗi cảnh đo 3 thời điểm (đầu / giữa / cuối) vì cú máy có thể đâm vào hình học giữa cảnh:
# cỡ cảnh chỉ chấm ở giữa, còn "chắn / trong vật đặc" phải sạch ở cả 3 thời điểm.
tot = good_shots = 0
worst = []
marks = (0.05, 0.50, 0.95)
for path in sorted(glob.glob(os.path.join("stories", "ep*.json"))):
    st = json.load(open(path, encoding="utf-8"))
    for s in st["shots"]:
        rig = rt_rigs.RIGS[s["anchor"]]
        band = rig["band"]
        if s.get("to"):
            bb = rt_rigs.RIGS[s["to"]]["band"]        # lia máy: chấp nhận dải của cả hai rig
            band = (min(band[0], bb[0]), max(band[1], bb[1]))
        who = next(iter(s["cast"]))
        mk = Vector(rt_rigs.mark_pos(s["cast"][who]))
        T = float(s["dur"])
        good2, why, frac_mid = True, "", 0.0
        for fr in marks:
            rt_cam.apply(s, T * fr, T)
            bpy.context.view_layer.update()
            cam = E.G.cam
            frac, foot, head, chest = measure(cam, mk)
            if inside_solid(cam):
                good2, why = False, "TRONG-VAT@%.0f%%" % (fr * 100)
                break
            ob = blocked(cam, mk + Vector((0, 0, rt_rigs.BODY * 0.55)))
            if ob:
                good2, why = False, "CHAN:%s@%.0f%%" % (ob, fr * 100)
                break
            if abs(fr - 0.5) < 1e-6:
                frac_mid = frac
                if not verdict(rig["kind"], band, frac, foot, head, chest):
                    good2, why = False, "BAND@50%"
        tot += 1
        good_shots += 1 if good2 else 0
        if not good2:
            worst.append((os.path.basename(path)[:-5] + "/" + s["id"], rig["kind"],
                          round(frac_mid, 2), band, why))
print("CẢNH THẬT: %d/%d đạt (%.1f%%)   [đo 3 thời điểm/cảnh]" % (
    good_shots, tot, 100.0 * good_shots / max(1, tot)))
for w in worst[:12]:
    print("  hỏng:", w)
print("cảnh không tìm được chỗ đặt camera sạch (rt_cam.UNRESOLVED):", len(rt_cam.UNRESOLVED))

sys.exit(0 if not bad and good_shots == tot else 1)
