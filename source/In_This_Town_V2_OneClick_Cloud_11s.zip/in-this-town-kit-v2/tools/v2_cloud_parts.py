#!/usr/bin/env python3
"""Validate the REAL original V2 renderer outputs, not any substituted visual generator."""
import argparse, json
from pathlib import Path
from PIL import Image,ImageStat
ROOT=Path(__file__).resolve().parents[1]
RUNTIME=ROOT.parent/'_runtime_v2'
STORY=json.loads((RUNTIME/'stories/v2_test_ep03.json').read_text(encoding='utf-8'))
FPS=int(STORY['fps']); TOTAL=round(STORY['seconds']*FPS)
assert len(STORY['shots'])==13 and FPS==24 and TOTAL==285, (len(STORY['shots']),FPS,TOTAL)

def inspect(p):
    if not p.exists() or p.stat().st_size<1500:raise RuntimeError('Missing/empty original V2 frame: '+str(p))
    with Image.open(p) as im:
        if im.size!=(1080,1920):raise RuntimeError(f'Wrong V2 resolution: {p} {im.size}')
        if max(ImageStat.Stat(im.convert('RGB')).stddev)<3:
            raise RuntimeError(f'Blank V2 frame: {p}')

def check(part=None):
    ids=[i for i in range(TOTAL) if part is None or i%3==part]
    for i in ids:inspect(RUNTIME/'build/frames'/f'f_{i:05d}.jpg')
    expected=TOTAL if part is None else len(ids)
    found=len(list((RUNTIME/'build/frames').glob('f_*.jpg')))
    if found!=expected:raise RuntimeError(f'Expected exactly {expected} frames, found {found}')
    print('PASSED original V2 1080x1920 Blender frames',found,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['validate','validate-all']);p.add_argument('--part',type=int)
    a=p.parse_args()
    if a.stage=='validate' and a.part not in [0,1,2]:p.error('--part must be 0, 1, or 2')
    check(a.part if a.stage=='validate' else None)
