"""tools/make_stories.py — CSV cảnh (đã đo) -> stories/epNN.json cho kit V2.

Không sinh lại số cảnh, không đổi thời lượng: chỉ chuyển định dạng.
    python tools/make_stories.py

Đọc:  D:\\CreatorIQ\\v5\\shots\\shotlist.csv          (tập 1)
      D:\\CreatorIQ\\v5\\shots\\shotlist-0N-*.csv      (tập 2..10)
Ghi:  stories/epNN.json, stories/epNN.py, data/epNN-subs.srt
"""
import csv
import glob
import json
import os
import shutil

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = r"D:\CreatorIQ\v5"
TITLES = {
    1: "Đọc Ý Đồ", 2: "Bóng Rời Chân", 3: "Số Trên Đầu", 4: "Loa Phường", 5: "Cái Cân Chợ",
    6: "Ghế Đá", 7: "Bảng Đen", 8: "Cửa Nhà", 9: "Đồng Hồ Ngược", 10: "Ảnh Gia Đình",
}
CROWD_ZONES = {"street": 6, "park": 6, "hall": 4, "shop": 4, "class": 2}


def src_csv(n):
    if n == 1:
        return os.path.join(SRC, "shots", "shotlist.csv")
    g = sorted(glob.glob(os.path.join(SRC, "shots", "shotlist-%02d-*.csv" % n)))
    return g[0] if g else None


def move_of(row, n):
    if row.get("to"):
        return "pan"
    if row.get("fovTo"):
        return "push"
    return "hold"


def convert(n, path):
    rows = list(csv.DictReader(open(path, encoding="utf-8")))
    shots = []
    for i, r in enumerate(rows):
        zone = r["anchor"].split("_")[0].lower()
        cast = {}
        for part in (r["cast"] or "").split(";"):
            if ":" in part:
                who, mk = part.split(":")
                cast[who.strip()] = mk.strip()
        exp = {}
        for part in (r["exp"] or "").split(";"):
            if ":" in part:
                who, f = part.split(":")
                exp[who.strip()] = f.strip()
        crowd = CROWD_ZONES.get(zone, 0) if i % 3 == 0 else 0
        shots.append({
            "id": r["id"], "line": r["text"].strip(), "law": r["line"].strip(), "set": zone,
            "anchor": r["anchor"], "to": r["to"] or "",
            "fov": float(r["fov"] or 42), "fovTo": float(r["fovTo"]) if r["fovTo"] else 0.0,
            "dutch": float(r["dutch"] or 0), "mood": r["mood"] or "day",
            "dur": round(float(r["dur"]), 2), "move": move_of(r, i),
            "cast": cast, "exp": exp, "crowd": crowd,
        })
    total = round(sum(s["dur"] for s in shots), 2)
    story = {
        "title": "Tập %d — %s" % (n, TITLES[n]),
        "voice": "vi-VN-NamMinhNeural",
        "rate": "+12%",
        "seconds": total,
        "fps": 24,
        "samples": 12,
        "lead": 0.10,
        "cut_lead": 0.06,
        "fx": {"speed_lines": False, "flash_into": []},
        "shots": shots,
    }
    out = os.path.join(HERE, "stories", "ep%02d.json" % n)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    json.dump(story, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    py = os.path.join(HERE, "stories", "ep%02d.py" % n)
    open(py, "w", encoding="utf-8").write(
        '"""V2: mọi cảnh lấy từ ep%02d.json, không viết tay hàm nào."""\n'
        "import os\nimport rt_story\n\n"
        "_J = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ep%02d.json')\n"
        "build, reset, SHOTS = rt_story.driver(_J)\n" % (n, n))
    subs = os.path.join(SRC, "build", "subs.srt" if n == 1 else "")
    if n == 1 and os.path.exists(subs):
        shutil.copy(subs, os.path.join(HERE, "data", "ep%02d-subs.srt" % n))
    else:
        g = sorted(glob.glob(os.path.join(SRC, "build", "%02d-*-subs.srt" % n)))
        if g:
            shutil.copy(g[0], os.path.join(HERE, "data", "ep%02d-subs.srt" % n))
    print("ep%02d: %3d cảnh, %6.1f s, %d câu có thoại -> stories/ep%02d.json"
          % (n, len(shots), total, sum(1 for s in shots if s["line"]), n))
    return len(shots), total


if __name__ == "__main__":
    os.makedirs(os.path.join(HERE, "data"), exist_ok=True)
    ts = tc = 0
    for n in range(1, 11):
        p = src_csv(n)
        if not p:
            print("thieu CSV tap", n)
            continue
        c, t = convert(n, p)
        tc += c
        ts += t
    print("TỔNG: %d cảnh, %.1f s" % (tc, ts))
