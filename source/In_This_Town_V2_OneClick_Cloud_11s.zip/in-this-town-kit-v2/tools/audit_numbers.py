"""tools/audit_numbers.py — đối chiếu từng con số trong tài liệu V2 với số thật.

Đọc V2-MAP.md, README.md, verify.py, stories/*.json, rt_rigs.py rồi so.
In PASS/FAIL cho từng con số; sai ở đâu sửa ở đó, không sửa số liệu cho khớp chữ.
"""
import glob
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
import rt_rigs

EXPECT_EP = [(1, 154, 148.5), (2, 151, 152.7), (3, 156, 155.5), (4, 145, 144.8), (5, 147, 142.2),
             (6, 151, 148.6), (7, 150, 147.2), (8, 146, 145.1), (9, 155, 151.7), (10, 161, 159.4)]
rows = []


def check(what, got, want):
    ok = got == want
    rows.append((what, ok, got, want))


stories = {}
for n, _, _ in EXPECT_EP:
    p = os.path.join(HERE, "stories", "ep%02d.json" % n)
    stories[n] = json.load(open(p, encoding="utf-8"))

shots = sum(len(s["shots"]) for s in stories.values())
secs = round(sum(x["dur"] for s in stories.values() for x in s["shots"]), 1)
lines = sum(1 for s in stories.values() for x in s["shots"] if x.get("line"))
push = sum(1 for s in stories.values() for x in s["shots"] if x.get("fovTo"))
dutch = sum(1 for s in stories.values() for x in s["shots"] if x.get("dutch"))
law = sum(1 for s in stories.values() for x in s["shots"] if x.get("law"))

check("tổng cảnh", shots, 1516)
check("tổng giây", secs, 1495.8)
check("số câu thoại", lines, 715)
check("số rig", len(rt_rigs.RIGS), 44)
check("số mark", len(rt_rigs.MARKS), 24)
check("số set", 8, 8)
check("push-in %", round(push / shots * 100), 60)
check("dutch %", round(dutch / shots * 100), 19)
check("vệt luật %", round(law / shots * 100), 93)
for n, c, d in EXPECT_EP:
    check("ep%02d cảnh" % n, len(stories[n]["shots"]), c)
    check("ep%02d giây" % n, round(sum(x["dur"] for x in stories[n]["shots"]), 1), d)

# so trong tai lieu
doc = open(os.path.join(HERE, "V2-MAP.md"), encoding="utf-8").read()
check("V2-MAP: 1516 cảnh", "**1516 cảnh / 1495,8 s**" in doc, True)
check("V2-MAP: 44 rig", "**44 rig**" in doc, True)
check("V2-MAP: 24 mark", "**24 mark**" in doc, True)
check("V2-MAP: 8 set", "**8 set**" in doc, True)
check("V2-MAP: 60% push", "**60%**" in doc, True)
check("V2-MAP: 19% dutch", "**19%**" in doc, True)
check("V2-MAP: 93% luật", "**93%**" in doc, True)
check("V2-MAP: 715 câu", "715 câu" in doc, True)
rd = open(os.path.join(HERE, "README.md"), encoding="utf-8").read()
check("README: 1516 cảnh", "1516 cảnh" in rd, True)
check("README: 44 rig", "44 camera rig" in rd, True)
check("README: 8 bối cảnh", "8 bối cảnh" in rd, True)

# so cua V1 (de doi chieu khi viet changelog)
import zipfile
if os.path.exists("D:/in-this-town-kit.zip"):          # chi kiem duoc khi con file V1
    z = zipfile.ZipFile("D:/in-this-town-kit.zip")
    check("V1: so file", len([n for n in z.namelist() if not n.endswith("/")]), 14)
faces = open(os.path.join(HERE, "rt_faces.py"), encoding="utf-8").read()
block = faces.split("FACES = [", 1)[1].split("]", 1)[0]
check("V1: so mat ve san", block.count(chr(34)) // 2, 16)
eng = open(os.path.join(HERE, "rt_engine.py"), encoding="utf-8").read()
mo = eng.split("MOODS = {", 1)[1].split(chr(10) + "}", 1)[0]
check("V1: so mood", len(re.findall(r"^    \"", mo, re.M)), 6)
sample = json.load(open(os.path.join(HERE, "stories", "last_one_awake.json"), encoding="utf-8"))
check("V1: story mau (giay)", int(sample["seconds"]), 20)
check("V1: story mau (canh)", len(sample["shots"]), 17)

bad = 0
for what, ok, got, want in rows:
    bad += 0 if ok else 1
    print("%-22s %-4s %s%s" % (what, "PASS" if ok else "FAIL", got,
                               "" if ok else "  (đúng phải là %s)" % want))
print("\n%d/%d PASS" % (len(rows) - bad, len(rows)))
sys.exit(1 if bad else 0)
