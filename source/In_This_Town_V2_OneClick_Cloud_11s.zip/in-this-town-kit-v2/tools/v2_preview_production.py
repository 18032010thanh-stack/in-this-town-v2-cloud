#!/usr/bin/env python3
"""Isolated, production-quality 11.87s Blender sample from the user's ORIGINAL V2 kit.

Does not use V1 stories, earlier 2D animatic, or touch the original 64 V2 files.
All real rendering/voice steps are performed by V2's own scripts. Two narrowly scoped
runtime-only compatibility/timing patches are explicitly documented below.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT.parent / '_runtime_v2'
MANIFEST = ROOT / 'V2-SOURCE-MANIFEST.json'
SOURCE = ROOT / 'stories' / 'ep03.json'
NAME = 'v2_test_ep03'
FIRST, END = 0, 13  # [s001..s013], inclusive of original 0-based index 12

# New scene timing function, exclusively replacing a copy of rt_render.shot_times.
# Original V2 math makes the preceding spoken shot zero-length if a blank shot
# follows it; this patch distributes the time span among ALL shots, weighted by dur.
TIMING_PATCH = '''def shot_times():
    n = len(story["shots"])
    ids = [s["id"] for s in story["shots"]]
    starts = [None] * n
    for w in words:
        idx = int(w["shot"])
        if 0 <= idx < n and starts[idx] is None:
            starts[idx] = max(0.0, float(w["t0"]) - lead)
    starts[0] = 0.0
    anchors = [(i, v) for i, v in enumerate(starts) if v is not None]
    anchors.append((n, total))
    for j in range(len(anchors)-1):
        a, lo = anchors[j]
        b, hi = anchors[j+1]
        lo = min(total, max(0.0, lo))
        hi = min(total, max(lo, hi))
        lengths = [max(0.01, float(story["shots"][k].get("dur") or 1)) for k in range(a, b)]
        s = sum(lengths)
        cur = 0.0
        for k, d in zip(range(a,b),lengths):
            starts[k] = lo + (hi-lo)*cur/s
            cur += d
    # Quantize boundaries ONCE and enforce nonzero shots when total frames allow.
    boundaries = [int(round(float(t or 0)*fps)) for t in starts] + [int(round(total*fps))]
    for i in range(1,len(boundaries)):
        if boundaries[i] <= boundaries[i-1]:
            boundaries[i] = boundaries[i-1]+1
    frames = int(round(total*fps))
    if boundaries[-1] > frames:
        # Reverse pass moves earlier cuts without moving the required final frame.
        boundaries[-1]=frames
        for i in range(len(boundaries)-2,-1,-1):
            boundaries[i]=min(boundaries[i],boundaries[i+1]-1)
    if boundaries[0]<0 or boundaries[-1]!=frames or any(boundaries[i]>=boundaries[i+1] for i in range(n)):
        raise RuntimeError("Not enough frames for nonzero shots; inspect voice timings")
    return [(ids[i],boundaries[i]/fps,boundaries[i+1]/fps) for i in range(n)]
'''


def sha(path:Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_files():
    """The immutable V2 member list, captured before appending demo files."""
    if not MANIFEST.exists():
        raise RuntimeError('Missing V2-SOURCE-MANIFEST.json')
    raw=json.loads(MANIFEST.read_text(encoding='utf-8'))
    return raw['source_files']


def verify_originals():
    expected=source_files()
    errors=[]
    for name, meta in expected.items():
        p=ROOT/name
        if not p.is_file():errors.append('missing: '+name)
        elif p.stat().st_size!=meta['bytes'] or sha(p)!=meta['sha256']:
            errors.append('changed: '+name)
    if errors:raise RuntimeError('V2 source not pristine:\n'+'\n'.join(errors))
    print('PASS: original V2 source untouched:',len(expected),'files',flush=True)


def story_data():
    d=json.loads(SOURCE.read_text(encoding='utf8'))
    if d['fps']!=24 or len(d['shots'])!=156:
        raise RuntimeError('Original V2 ep03 is unexpected; check file')
    return d


def prepare():
    verify_originals()
    if RUNTIME.exists():
        # Never wipe an existing live render without operator action.
        mark=RUNTIME/'_v2_test_signature.json'
        if not mark.is_file() or json.loads(mark.read_text())['source_sha256']!=sha(SOURCE):
            raise RuntimeError(f'Existing runtime incompatible: {RUNTIME}; move it manually')
        print('Reuse isolated runtime:',RUNTIME)
    else:
        RUNTIME.mkdir(parents=True)
        for name in source_files():
            dest=RUNTIME/name
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(ROOT/name,dest)
        (RUNTIME/'_v2_test_signature.json').write_text(json.dumps({'source_sha256':sha(SOURCE),'source_count':len(source_files())},indent=2))
    story=story_data()
    sample={k:v for k,v in story.items() if k!='shots'}
    sample['title'] = story['title'] + ' — BẢN TEST V2 3D (s001–s013)'
    sample['shots'] = story['shots'][FIRST:END]
    sample['seconds'] = round(sum(float(s['dur']) for s in sample['shots']),2)
    assert len(sample['shots'])==13 and 11<=sample['seconds']<=13
    samp=RUNTIME/'stories'/f'{NAME}.json'
    samp.write_text(json.dumps(sample,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # Same generic data-driven V2 story driver, not the old hard-coded example.
    (RUNTIME/'stories'/f'{NAME}.py').write_text('''"""V2 isolated sample, original shots from stories/ep03.json"""\nimport os\nimport rt_story\n_J=os.path.join(os.path.dirname(os.path.abspath(__file__)), "v2_test_ep03.json")\nbuild,reset,SHOTS=rt_story.driver(_J)\n''',encoding='utf-8')
    renderer=(RUNTIME/'rt_render.py')
    content=(ROOT/'rt_render.py').read_text(encoding='utf-8')
    before='def shot_times():'
    after='\nTIMES = shot_times()'
    if content.count(before)!=1 or content.count(after)!=1:raise RuntimeError('Incompatible V2 rt_render.py; refusing unsafe patch')
    start=content.index(before);end=content.index(after)
    content=content[:start]+TIMING_PATCH+content[end:]
    renderer.write_text(content,encoding='utf-8')
    # Blender 5.x Cycles compatibility: denoising moved to ViewLayer on some versions.
    engine=(RUNTIME/'rt_engine.py'); content=(ROOT/'rt_engine.py').read_text(encoding='utf-8')
    old='        s.cycles.use_denoising = True'
    new='''        for layer in s.view_layers:
            if hasattr(layer, "cycles") and hasattr(layer.cycles, "use_denoising"):
                layer.cycles.use_denoising = True'''
    if content.count(old)!=1:raise RuntimeError('Unknown V2 Cycles denoising code')
    engine.write_text(content.replace(old,new),encoding='utf-8')
    print('PREPARED',sample['title'], 'shots',len(sample['shots']), 'length',sample['seconds'],'seconds',sample['fps'],'fps', flush=True)
    print('V2 source rt_render.py and rt_engine.py remain byte-for-byte original.',flush=True)
    return sample


def command(*args, need_blender=False):
    env=dict(os.environ)
    env.setdefault('RT_ENGINE','CYCLES')
    env.setdefault('CAPTION_FONT','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf')
    blender_exe=os.environ.get('BLENDER') or shutil.which('blender')
    if need_blender and not blender_exe:
        raise RuntimeError('Blender unavailable: set BLENDER to Blender 5.x executable or install it in PATH')
    if args and args[0]=='blender' and blender_exe:
        args=(blender_exe,*args[1:])
    start=time.perf_counter()
    print('\n$',' '.join(map(str,args)),flush=True)
    subprocess.run(list(map(str,args)),cwd=RUNTIME,env=env,check=True)
    print('Finished in %.1f s' % (time.perf_counter()-start),flush=True)


def assert_voice():
    d=json.loads((RUNTIME/'build/words.json').read_text(encoding='utf8'))
    assert d['voice']=='vi-VN-NamMinhNeural'
    assert len(d['words'])>=20
    assert (RUNTIME/'build/vo.wav').stat().st_size>10000
    sample=json.loads((RUNTIME/'stories'/f'{NAME}.json').read_text(encoding='utf8'))
    assert d['duration'] <= sample['seconds'] + .05, 'Narration runs past sample; adjust real TTS voice rate'
    print('VOICE OK',d['voice'],round(d['duration'],2),'sec,',len(d['words']),'word cues')
    return d


def make_srt():
    data=assert_voice();shots=json.loads((RUNTIME/'stories'/f'{NAME}.json').read_text(encoding='utf8'))['shots']
    def mark(t):
        ms=max(0,int(round(t*1000)))
        h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000)
        return f'{h:02d}:{m:02d}:{s:02d},{ms:03d}'
    lines=[];count=0
    for i,s in enumerate(shots):
        if not s['line']:continue
        ws=[w for w in data['words'] if w['shot']==i]
        if not ws:raise RuntimeError('No real TTS word timings for '+s['id'])
        a=ws[0]['t0'];b=ws[-1]['t1']
        if b<=a:raise RuntimeError('Invalid TTS timings '+s['id'])
        count+=1;lines.append(f'{count}\n{mark(a)} --> {mark(b)}\n{s["line"]}\n')
    path=RUNTIME/'build'/'test_v2_vietsub.srt'
    path.write_text('\n'.join(lines),encoding='utf8')
    print('SRT OK',count,'authentic Vietnamese dialogue cues')
    return path


def test_timing_static():
    """Test the real rt_render patch on mock first-word timings without any Blender."""
    d=json.loads((RUNTIME/'stories'/f'{NAME}.json').read_text(encoding='utf8'))
    import ast
    prog=ast.parse((RUNTIME/'rt_render.py').read_text(encoding='utf8'))
    fn=next(x for x in prog.body if isinstance(x,ast.FunctionDef) and x.name=='shot_times')
    words=[];t=0.0
    for i,s in enumerate(d['shots']):
        if s['line']:words.append({'shot':i,'t0':t+0.10,'t1':t+0.24,'word':s['line'].split()[0]})
        t+=s['dur']
    ctx=dict(story=d,words=words,lead=d['cut_lead'],fps=d['fps'],total=d['seconds'])
    exec(compile(ast.Module(body=[fn],type_ignores=[]),'<timing-test>','exec'),ctx)
    a=ctx['shot_times']()
    assert len(a)==13
    assert all(x[1]<x[2] for x in a),a
    assert a[0][1]==0.0
    assert abs(a[-1][2]-d['seconds'])<1/d['fps']
    print('PASS timing: all 13 V2 shots receive real nonzero screen time')


def test_textures():
    from PIL import Image
    for name in ('faces.png','clock.png','alarm_nine.png','alarm_late.png','lightsout.png','nocoffee.png','poster_rocket.png','poster_sleep.png'):
        p=RUNTIME/'build/tex'/name
        if not p.is_file():raise RuntimeError('V2 texture missing '+name)
        with Image.open(p) as im:im.verify()
    print('PASS all 8 original V2 textures present and decodable')


def check_frames(stills=False):
    from PIL import Image,ImageStat
    d=RUNTIME/'build'/('stills' if stills else 'frames')
    if stills:
        frames=sorted(d.glob('[0-9]*.jpg'))
        expected=13*3
    else:
        sample=json.loads((RUNTIME/'stories'/f'{NAME}.json').read_text(encoding='utf8'))
        expected=round(sample['seconds']*sample['fps'])
        frames=[d/f'f_{k:05d}.jpg' for k in range(expected)]
    if len(frames)!=expected:raise RuntimeError(f'Expected {expected} still/frame files; found {len(frames)}')
    for p in frames:
        if not p.exists() or p.stat().st_size<1500:raise RuntimeError(f'Invalid render frame {p}')
    inspect=[frames[0],frames[len(frames)//2],frames[-1]]
    for p in inspect:
        with Image.open(p) as im:
            if not stills and im.size!=(1080,1920):raise RuntimeError(f'Not full production resolution {p}: {im.size}')
            if max(ImageStat.Stat(im.convert('RGB')).stddev)<3.0:raise RuntimeError(f'Blank frame {p}')
    print('PASS',expected,('stills' if stills else 'full-resolution Blender frames'),'nonblank')


def verify_mp4():
    p=RUNTIME/'build/FINAL.mp4'
    raw=subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-show_entries','stream=codec_name,codec_type,width,height,nb_frames,avg_frame_rate','-of','json',str(p)],text=True)
    v=json.loads(raw)
    clips={s['codec_type']:s for s in v['streams']}
    dur=json.loads((RUNTIME/'stories'/f'{NAME}.json').read_text(encoding='utf8'))['seconds']
    assert 'video' in clips and 'audio' in clips,v
    assert clips['video']['codec_name']=='h264'
    assert clips['audio']['codec_name']=='aac'
    assert clips['video']['width']==1080 and clips['video']['height']==1920
    assert int(clips['video']['nb_frames'])==round(dur*24)
    assert abs(float(v['format']['duration'])-dur)<0.09
    print('PRODUCTION MP4 VERIFIED',p,'seconds',v['format']['duration'])


def run_stage(stage):
    prepare()
    test_timing_static()
    test_textures()
    if stage=='prepare':return
    if stage in ('voice','all'):
        command(sys.executable,'rt_voice.py',f'stories/{NAME}.json')
        make_srt()
    if stage in ('textures','all'):
        command(sys.executable,'rt_faces.py')
        test_textures()
    if stage in ('stills','all'):
        assert_voice()
        command('blender','-b','--factory-startup','--python','rt_render.py','--',f'stories/{NAME}.json','--stills','--scale','40',need_blender=True)
        check_frames(stills=True)
        command(sys.executable,'rt_sheet.py','5')
    if stage in ('render','all'):
        assert_voice()
        # Source sample only; no --preview -> true 1080x1920, 24fps V2 frames.
        command('blender','-b','--factory-startup','--python','rt_render.py','--',f'stories/{NAME}.json','--scale','100',need_blender=True)
        check_frames(stills=False)
    if stage in ('finish','all'):
        make_srt()
        check_frames(stills=False)
        command(sys.executable,'rt_finish.py',f'stories/{NAME}.json')
        verify_mp4()


def main():
    p=argparse.ArgumentParser(description='Genuine, isolated V2 production video preview')
    p.add_argument('stage',choices=('prepare','voice','textures','stills','render','finish','all'))
    args=p.parse_args()
    run_stage(args.stage)


if __name__=='__main__':
    main()
