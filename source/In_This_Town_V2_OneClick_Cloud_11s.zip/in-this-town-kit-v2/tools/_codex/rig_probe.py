﻿"""Run with Blender -b --factory-startup --python tools/_codex/rig_probe.py.
Reports the centre of a 5.32-stud neutral body, projected height, distance,
and first obstruction to the centre. Includes the actual build-time guard.
"""
import os, sys
sys.path.insert(0, os.getcwd())
import bpy
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
import rt_engine as E, rt_sets, rt_story, rt_rigs, rt_cam
E.new_scene(1080, 1920, 24, 4)
class Context: pass
ctx = Context(); ctx.sets = rt_sets.build(); ctx.chars = {}
rt_story._clear_cameras(ctx)
scene = bpy.context.scene
for name, rig in rt_rigs.RIGS.items():
    mark = Vector(rt_rigs.mark_pos(rig['zone'].upper() + '_MK1'))
    rt_cam.apply({'anchor': name, 'move': 'hold'}, 0, 1)
    bpy.context.view_layer.update()
    cam = E.G.cam
    center = mark + Vector((0, 0, 2.66))
    mid = world_to_camera_view(scene, cam, center)
    foot = world_to_camera_view(scene, cam, mark)
    head = world_to_camera_view(scene, cam, mark + Vector((0, 0, 5.32)))
    dist = (cam.location - mark).length
    d = center - cam.location
    hit, loc, normal, idx, obj, matrix = scene.ray_cast(bpy.context.evaluated_depsgraph_get(), cam.location, d.normalized(), distance=d.length)
    good = mid.z > 0 and 0.15 <= mid.x <= 0.85 and 0.15 <= mid.y <= 0.85 and 0.30 <= abs(head.y-foot.y) <= 0.75
    print('PROBE %s ndc=%.3f,%.3f height=%.3f dist=%.2f obstruction=%s framed=%s' % (name, mid.x, mid.y, abs(head.y-foot.y), dist, obj.name if hit else '-', good))
