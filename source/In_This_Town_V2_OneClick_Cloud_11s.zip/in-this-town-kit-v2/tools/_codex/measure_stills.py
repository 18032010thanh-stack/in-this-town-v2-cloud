﻿"""Blender: -b --factory-startup --python tools/_codex/measure_stills.py -- build/stills/*s02*.jpg
NumPy skin-colour proxy is not segmentation: similarly coloured sets cause false positives.
Brightness and colours use Blender's decoded scene-linear RGB (0..1).
"""
import glob, sys, os
import bpy
import numpy as np
for arg in sys.argv[sys.argv.index('--') + 1:]:
    for path in sorted(glob.glob(arg)):
        img = bpy.data.images.load(os.path.abspath(path), check_existing=False)
        a = np.empty(len(img.pixels), dtype=np.float32)
        img.pixels.foreach_get(a)
        a = a.reshape(-1, 4)[:, :3]
        # Convert scene-linear to sRGB for the conventional 8-bit skin proxy.
        s = np.where(a <= .0031308, 12.92 * a, 1.055 * np.power(np.maximum(a, 0), 1 / 2.4) - .055) * 255
        r, g, b = s.T
        mask = (r > 95) & (g > 45) & (b > 25) & (r > g * 1.08) & (g > b * 1.03) & ((r - b) > 25)
        print(f'MEASURE {path} mean_brightness_srgb={s.mean():.2f}/255 skin_proxy={mask.mean():.4%}')
        bpy.data.images.remove(img)

