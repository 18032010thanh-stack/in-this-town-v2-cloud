# Upload ONLY user-provided In This Town Kit V2 into a NEW PRIVATE GitHub repo,
# then launch its existing 11.87-second Blender + real Vietnamese TTS workflow.
# This script does not access or change any repository associated with V1.
param([string]$RepoName = 'in-this-town-kit-v2-cloud')
$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
Set-Location -LiteralPath $Root

function Assert-Ok([string]$Step) {
    if ($LASTEXITCODE -ne 0) { throw "$Step failed (exit code $LASTEXITCODE)" }
}
function Has-Command([string]$Command) {
    return [bool](Get-Command $Command -ErrorAction SilentlyContinue)
}
if (-not (Has-Command 'gh')) {
    throw 'GitHub CLI is missing. Install with: winget install --id GitHub.cli --exact  then reopen PowerShell.'
}
if (-not (Has-Command 'git')) {
    throw 'Git is missing. Install with: winget install --id Git.Git --exact  then reopen PowerShell.'
}
if (-not (Test-Path -LiteralPath 'V2-SOURCE-MANIFEST.json')) {
    throw 'This must run INSIDE the extracted in-this-town-kit-v2 folder, with the full V2 source.'
}
# Verify all 64 original V2 source assets before pushing the bundle.
$Manifest = Get-Content -Raw -Encoding UTF8 'V2-SOURCE-MANIFEST.json' | ConvertFrom-Json
$N = 0
foreach ($Entry in $Manifest.source_files.PSObject.Properties) {
    $Relative = [string]$Entry.Name
    $Expected = [string]$Entry.Value.sha256
    $ExpectedSize = [long]$Entry.Value.bytes
    $Absolute = Join-Path $Root ($Relative.Replace('/', [IO.Path]::DirectorySeparatorChar))
    if (-not (Test-Path -LiteralPath $Absolute -PathType Leaf)) { throw "Missing V2 source: $Relative" }
    if ((Get-Item -LiteralPath $Absolute).Length -ne $ExpectedSize) { throw "Size mismatch: $Relative" }
    $Digest = (Get-FileHash -LiteralPath $Absolute -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($Digest -ne $Expected) { throw "V2 source changed: $Relative" }
    $N++
}
if ($N -ne 64) { throw "Expected exactly 64 source files; found $N" }
Write-Host "Verified all $N original V2 files, byte-for-byte." -ForegroundColor Green

& gh auth status *> $null
if ($LASTEXITCODE -ne 0) {
    Write-Host 'Sign in securely through the GitHub website (no token pasted into ChatGPT).'
    & gh auth login --hostname github.com --web --git-protocol https
    Assert-Ok 'GitHub login'
}
$Owner = ((& gh api user --jq .login) | Out-String).Trim()
Assert-Ok 'Read GitHub account'
if (-not $Owner) { throw 'Cannot determine GitHub username' }
if ($RepoName -notmatch '^[a-zA-Z0-9_.-]+$') { throw 'Invalid repository name' }
$Repo = "$Owner/$RepoName"
& gh repo view $Repo --json name --jq .name *> $null
if ($LASTEXITCODE -eq 0) { throw "Repository $Repo already exists; refusing to overwrite an existing project." }
if (Test-Path '.git') { throw 'This directory already has a .git folder. Use a fresh extracted ZIP to avoid changing another repository.' }

# The only new repository is private. Existing V1 repositories are never contacted.
& git init -b main
Assert-Ok 'git init'
& git add -A
Assert-Ok 'git add'
$Id = ((& gh api user --jq .id) | Out-String).Trim()
Assert-Ok 'Read GitHub user ID'
& git -c "user.name=$Owner" -c "user.email=$Id+$Owner@users.noreply.github.com" commit -m 'Initial V2-only production test; keep all 64 original files'
Assert-Ok 'git commit'
& gh repo create $Repo --private --source . --remote origin --push --description 'Private original In This Town V2 Blender production preview'
Assert-Ok 'Create private repository and upload V2'
Write-Host "NEW PRIVATE REPOSITORY: https://github.com/$Repo" -ForegroundColor Green
Write-Host 'This 11.87-second Blender render may consume your private GitHub Actions minutes.' -ForegroundColor Yellow
$Confirmation = (Read-Host 'Start the real V2 Cloud render now? Type YES').Trim()
if ($Confirmation -ne 'YES') {
    Write-Host "Repository was created but no rendering was started. You may launch the workflow manually: https://github.com/$Repo/actions"
    exit 0
}
$Started = $false
for ($Attempt = 1; $Attempt -le 12; $Attempt++) {
    & gh workflow run 'v2-real-production-test.yml' --repo $Repo --ref main
    if ($LASTEXITCODE -eq 0) { $Started = $true; break }
    Start-Sleep -Seconds 5
}
if (-not $Started) { throw "GitHub repository exists, but workflow dispatch did not succeed. Open https://github.com/$Repo/actions" }
Write-Host "V2-ONLY render request submitted: https://github.com/$Repo/actions" -ForegroundColor Green
Write-Host 'The workflow installs Blender, generates real Edge TTS voice, renders 13 V2 scenes in 1080x1920 and checks FINAL.mp4.'
Write-Host 'After completion, download artifact: V2-ep03-real-3D-test-11s'
