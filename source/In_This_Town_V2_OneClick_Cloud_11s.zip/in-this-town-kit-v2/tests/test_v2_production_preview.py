"""Offline proof of V2 provenance, exhaustive archive audit and preview framing logic."""
import ast
import hashlib
import json
import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import v2_preview_production as v2

class TestRealV2Preview(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        v2.prepare()

    def test_all_64_source_hashes_untouched(self):
        for p,meta in v2.source_files().items():
            self.assertEqual(hashlib.sha256((ROOT/p).read_bytes()).hexdigest(),meta['sha256'],p)
        self.assertEqual(len(v2.source_files()),64)

    def test_selected_shots_are_the_original_v2_episode_three(self):
        original=json.loads((ROOT/'stories/ep03.json').read_text(encoding='utf8'))
        sample=json.loads((v2.RUNTIME/'stories/v2_test_ep03.json').read_text(encoding='utf8'))
        self.assertEqual(sample['shots'],original['shots'][:13])
        self.assertEqual(sample['fps'],24)
        self.assertEqual(sample['voice'],'vi-VN-NamMinhNeural')
        self.assertEqual(sample['seconds'],11.87)
        self.assertEqual(len({s['set'] for s in sample['shots']}),3)

    def test_8_png_assets_open(self):
        v2.test_textures()

    def test_v2_render_timing_fixed_without_touching_source(self):
        v2.test_timing_static()
        self.assertEqual(v2.sha(ROOT/'rt_render.py'),v2.source_files()['rt_render.py']['sha256'])
        self.assertNotEqual(v2.sha(ROOT/'rt_render.py'),v2.sha(v2.RUNTIME/'rt_render.py'))
        self.assertNotEqual(v2.sha(ROOT/'rt_engine.py'),v2.sha(v2.RUNTIME/'rt_engine.py'))

    def test_runtime_patch_valid_python(self):
        for f in ('rt_render.py','rt_engine.py'):
            ast.parse((v2.RUNTIME/f).read_bytes())

if __name__=='__main__': unittest.main(verbosity=2)
