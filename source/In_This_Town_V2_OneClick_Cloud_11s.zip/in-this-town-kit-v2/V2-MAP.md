# V2-MAP — kiến trúc V2 nằm ở đâu, lấy từ đâu, khác V1 chỗ nào

Bản này để bạn soi, không phải tin lời tôi. Mỗi con số ghi kèm file sinh ra nó.

## 1. Số liệu (đo lại bằng `verify.py`)

| Việc | Nguồn | Số |
|---|---|---|
| Kịch bản từng tập | `stories/ep01..10.json` | 715 câu thoại |
| Số cảnh mỗi tập | `stories/epNN.json` | 154 · 151 · 156 · 145 · 147 · 151 · 150 · 146 · 155 · 161 |
| Thời lượng mỗi tập | như trên | 148,5 · 152,7 · 155,5 · 144,8 · 142,2 · 148,6 · 147,2 · 145,1 · 151,7 · 159,4 s |
| Tổng | 10 tập | **1516 cảnh / 1495,8 s** |
| Camera rig | `rt_rigs.py` | **44 rig** (9 street · 5 hall · 5 class · 9 park · 4 shop · 4 kitchen · 3 bedroom · 5 cellar) |
| Mark đặt cast | `rt_rigs.MARKS` | **24 mark** (8 khu × 3) |
| Bối cảnh | `rt_sets.py` | **8 set** |
| Push-in | 10 tập | **60%** cảnh |
| Dutch | 10 tập | **19%** cảnh |
| Vệt luật | 10 tập | **93%** cảnh |
| Nhịp | `stories/*.json` | 24 fps, 0,96–1,01 s/cảnh, khung 1080×1920 |
| Chiều cao nhân vật | đo bound box mesh Bo, seed tất định | **6,033 stud** (trước khi cố định seed thì mỗi lần chạy ra 6,05–6,17) |
| Bố cục 44 rig | `tools/framing_check.py` | **44/44 PASS** |
| Bố cục 1516 cảnh thật | `tools/framing_check.py`, **3 thời điểm/cảnh** | **1516/1516 đạt (100%)**, 0 cảnh bí chỗ đặt camera |

## 2. Từng phần của V1, V2 đổi gì

| V1 | V2 | Vì sao |
|---|---|---|
| `Street`, `Room` (2 set) | `rt_sets.py`: 8 set (street, hall, class, park, shop, kitchen, bedroom, cellar) | 150 cảnh/tập không thể quay trong 2 chỗ |
| 6 mood (`day/dusk/night/room/room_dusk/room_night`) | giữ nguyên 6 mood, dùng mood `day/dusk/night` cho cả 8 set | V1 đã đủ; thêm mood chỉ làm chậm render |
| camera đặt tay trong từng hàm cảnh | `rt_rigs.py` (44 rig, có luật khoảng cách 4,5 / 9 / <5 stud) + `rt_cam.py` (push, pan, whip, orbit, crane, handheld, dutch) | 154 cảnh/tập không thể đặt tay; và cần đúng khoảng cách |
| 1 hàm Python cho mỗi cảnh (viết tay) | `rt_story.py` đọc JSON, tự dựng cảnh | 10 tập × 150 cảnh = 1.500 hàm nếu viết tay |
| 1 story mẫu 20 s | 10 story 142–159 s, sinh từ CSV đã đo | để kết quả đã thống nhất không bị đổi |
| `rt_render.shot_times()` giả định mỗi cảnh 1 câu | sửa: cảnh không thoại chia đều theo `dur` | V2 có 2 cảnh/câu, cảnh thứ 2 không có lời |
| `rt_finish.py` font cứng `C:\Windows\Fonts\seguibl.ttf` | danh sách font dự phòng + `CAPTION_FONT` | chạy trên Cloud (Linux) và cần dấu tiếng Việt |
| engine cứng `BLENDER_EEVEE` | đọc `RT_ENGINE` để chuyển `CYCLES` (CPU) | máy không GPU vẫn render được |
| — | `verify.py` 14 phép kiểm | để sai số bị phát hiện, không phải tin lời |

## 3. Luật Studio → Blender (không dập khuôn)

| Studio (V5) | Blender (V2) |
|---|---|
| roll camera 90°, hậu kỳ xoay | render thẳng 1080×1920, chỉ còn `dutch` |
| quay 30 fps | render **24 fps** (bớt 20% số khung) |
| neo = Part vô hình | neo = số trong `rt_rigs.py` |
| 11 thuộc tính Lighting + 4 effect | `E.mood()` (trời 2 màu + nắng + fill) |
| FaceControls / Decal | 16 mặt vẽ sẵn trong `rt_faces.py` |
| R15 anim id | `.pose()/.walk()/.run()` theo từng frame |
| BillboardGui tag `Rotation 90` | 3D text gắn vào đầu, xoay về camera mỗi frame |
| phím `C` kiểm khung | `verify.py` + tờ stills `rt_sheet.py` |

## 4. Cái V2 **chưa** làm được (phải chạy trên Cloud)

1. **Chưa render 1 tập nào** — mới render 6 khung thử ở nhà (Cycles CPU) để chứng minh pipeline chạy.
2. **EEVEE không chạy trên máy này** (Intel HD), nên mọi đánh giá "đẹp/rẻ" phải làm ở Cloud.
3. **Đã sửa bố cục** (xem §5) nhưng chưa xem bằng mắt từng cảnh: máy này render 1 khung mất 30–60 s, không đủ để duyệt 1516 cảnh.
4. **Giọng tiếng Việt chưa thu** — `rt_voice.py` đã trỏ `vi-VN-NamMinhNeural` nhưng cần mạng để chạy.

## 5. Bố cục — số đo, không phải ý kiến

Luật: `frac` = chiều cao nhân vật / chiều cao khung, và khoảng cách rig được **tính**
từ `frac` chứ không đặt tay:

    D = (BODY / frac) / (2 * tan(fov/2))        BODY = 6,033 stud

| Kiểu rig | frac mục tiêu | dải hợp lệ (ngoài trời) | trong nhà (×1,25) |
|---|---|---|---|
| `_W` | 0.58 | 0.45–0.80 | 0.56–1.00 |
| `_M` | 0.65 | 0.55–0.90 | 0.69–1.12 |
| `_C` | 1.25 | 0.95–1.75 | 1.19–2.19 |
| `_L` | 0.62 | 0.42–0.78 | 0.53–0.98 |
| `_TOP` | 0.40 | 0.10–0.70 | 0.12–0.88 |
| `_LOW` | 0.85 | 0.65–1.10 | 0.81–1.38 |
| `_SIDE` | 0.58 | 0.40–0.75 | 0.50–0.94 |
| `_N` | 0.65 | 0.55–0.80 | 0.69–1.00 |
| `_NE` | 0.60 | 0.45–0.75 | 0.56–0.94 |
| `_SW` | 0.60 | 0.45–0.75 | 0.56–0.94 |
| `_DOOR` | 1.00 | 0.75–1.30 | 0.94–1.62 |
| `_UP` | 1.25 | 1.05–5.60 | 1.31–7.00 |
| `_DARK` | 1.15 | 0.85–1.60 | 1.06–2.00 |
| `_SIGN` | 0.45 | 0.45–0.85 | 0.56–1.06 |
| `_TILT` | 0.65 | 0.50–0.80 | 0.62–1.00 |

Ba thứ phải cùng đúng thì cảnh mới gọi là "đúng khung":

1. chiều cao nhân vật trong dải của kiểu rig;
2. thân người nằm giữa khung (rig rộng phải thấy cả đầu và chân; rig cận được cắt mép);
3. **không nằm trong vật đặc** (bắn 6 hướng, 6 hướng đều đụng mặt kín trong 0,25 stud = đang ở trong khối)
   và **không có vật chắn** giữa camera và ngực nhân vật (raycast; bỏ qua chính nhân vật).

Cảnh có `to` (lia máy sang rig khác) được chấm bằng **dải gộp của cả hai rig**, vì camera
thật sự ở giữa hai cỡ cảnh trong suốt cú lia. Dải của `_TOP`/`_UP` rộng hơn hẳn các kiểu
khác vì nhìn từ trên xuống / dưới lên thì thân người bị thu ngắn theo phép chiếu.

Sửa gì để đạt 44/44 và 1516/1516:

| Sửa | Trước | Sau |
|---|---|---|
| Góc nhìn | Blender hiểu `angle` là góc **ngang** | `rt_cam` đặt `lens` theo `sensor_height` (đúng góc dọc) |
| Khoảng cách rig | đặt tay (4,8–15 stud) | tính từ `frac` (6,6–16,7 stud) |
| Cao độ điểm ngắm | số tuyệt đối 2,6 | `BODY × 0,44…0,70` |
| Phòng trong nhà | 20×18 → chỉ lùi 7 stud | 34×30 (bếp), 34×30 (buồng), 32×28 (hầm) |
| Đồ đạc trong phòng | nằm giữa phòng | dồn nửa `-y`; camera ở nửa `+y` trống |
| Camera ngoài trời | lọt vào tường nhà ở `y` 15,5 | `LIMIT` phố `|y| ≤ 15`, sân `≤ 22` |
| `fov` trong CSV | 30–62 phá cỡ cảnh | chặn trong `rig_fov − 12 … + 8`, rồi lùi/tiến bù lại |
| Vật cản | không kiểm | `tools/framing_check.py`: raycast + phép thử "trong vật đặc" cho 44 rig **và** 1516 cảnh |
| Vật cản giữa cảnh | không có | `rt_cam._resolve()` thử 10 vị trí thay thế mỗi khung hình, ghi lại cảnh không giải được; checker đo ở 5% / 50% / 95% thời lượng cảnh |
| Chiều cao nhân vật | `hash()` đổi theo phiên → 6,05–6,17 stud | seed tất định theo tên → 6,033 stud mọi lần chạy |
