"""rt_rigs.py — 44 camera rig + 8 cú máy, chỉ toán học, không cần Blender.

Thay cho neo Part trong Roblox Studio: ở đây rig là con số.
Mỗi shot trong stories/*.json chỉ cần ghi `anchor` (và `to` nếu có lia máy),
rt_cam tự đặt camera đúng khoảng cách, đúng hướng, đúng độ nghiêng.

Luật khoảng cách (sửa lần 2, có đo): nhân vật V2 cao **6,15 stud** (đo bound box
của mesh Bo, không phải 4,5–5 như ước lượng ban đầu). Vì vậy khoảng cách rig được
TÍNH từ tỉ lệ khung mong muốn, không đặt tay:

    D = (BODY / frac) / (2 * tan(fov/2))

frac = chiều cao nhân vật / chiều cao khung. `_W/_M/_L` cần 0,55–0,70 (toàn thân),
`_C` 1,25 (cận ngực), `_DARK/_DOOR` ~1,0–1,15. Mỗi kiểu có dải riêng trong BAND.
"""
import math

BODY = 6.033                     # chiều cao nhân vật, stud — đo từ mesh Bo, seed tất định

# (rộng, sâu) từng khu, stud — phòng trong nhà phải đủ sâu cho rig _L (15 stud)
ZONE = {
    "street": (200, 40), "hall": (40, 34), "class": (40, 34), "park": (80, 44),
    "shop": (40, 34), "kitchen": (34, 30), "bedroom": (34, 30), "cellar": (32, 28),
}

ORIGIN = {
    "street": (0, 0, 0), "hall": (0, 300, 0), "class": (0, 600, 0), "park": (0, 900, 0),
    "shop": (0, 1200, 0), "kitchen": (0, 1500, 0), "bedroom": (0, 1800, 0), "cellar": (0, 2100, -9),
}

# kiểu rig: frac = chiều cao nhân vật / chiều cao khung mong muốn,
# high = độ cao camera, side = lệch ngang, fov = góc nhìn DỌC, look = cao độ điểm ngắm
KIND = {
    # look = cao độ điểm ngắm, tính theo BODY: 0,50 = ngang ngực, 0,62 = ngang cằm
    "W":    dict(frac=0.58, high=2.6, side=0.0,  fov=42, look=0.50),
    "M":    dict(frac=0.65, high=2.2, side=0.0,  fov=44, look=0.60),
    "C":    dict(frac=1.25, high=2.6, side=0.0,  fov=40, look=0.66),
    "L":    dict(frac=0.62, high=0.9, side=0.0,  fov=40, look=0.44),
    "TOP":  dict(frac=0.40, high=8.0, side=3.0, fov=50, look=0.10),
    "LOW":  dict(frac=0.85, high=1.2, side=0.0,  fov=50, look=0.62),
    "SIDE": dict(frac=0.58, high=2.4, side=9.0,  fov=44, look=0.50),
    "N":    dict(frac=0.65, high=2.3, side=0.0,  fov=44, look=0.60),
    "NE":   dict(frac=0.60, high=2.8, side=7.0,  fov=46, look=0.50),
    "SW":   dict(frac=0.60, high=2.4, side=-7.0, fov=46, look=0.50),
    "DOOR": dict(frac=1.00, high=2.0, side=0.0,  fov=42, look=0.58),
    "UP":   dict(frac=1.25, high=1.1, side=0.0,  fov=50, look=0.62),
    "DARK": dict(frac=1.15, high=1.6, side=4.5,  fov=38, look=0.52),
    "SIGN": dict(frac=0.45, high=2.8, side=0.0,  fov=34, look=0.70),
    "TILT": dict(frac=0.65, high=2.2, side=2.0,  fov=44, look=0.55),
}

# dải chiều cao khung hợp lệ theo kiểu rig (không dùng một dải cho tất cả)
# Dải chiều cao khung hợp lệ theo kiểu rig. TOP/UP rộng hơn vì nhìn từ trên xuống
# hoặc từ dưới lên thì thân người bị thu ngắn theo phép chiếu (foreshortening),
# nên cùng một cỡ cảnh vẫn cho frac rất khác nhìn ngang.
BAND = {
    "W": (0.45, 0.80), "M": (0.55, 0.90), "C": (0.95, 1.75), "L": (0.42, 0.78),
    "TOP": (0.18, 0.95), "LOW": (0.65, 1.10), "SIDE": (0.40, 0.75), "N": (0.55, 0.80),
    "NE": (0.45, 0.75), "SW": (0.45, 0.75), "DOOR": (0.75, 1.30), "UP": (1.05, 5.60),
    "DARK": (0.85, 1.60), "SIGN": (0.45, 0.85), "TILT": (0.50, 0.80),
}

RIG_NAMES = {
    "street": ["STREET_W", "STREET_M", "STREET_C", "STREET_L", "STREET_SIGN", "STREET_TILT",
               "STREET_TOP", "STREET_N", "STREET_SIDE"],
    "hall": ["HALL_W", "HALL_M", "HALL_C", "HALL_L", "HALL_LOW"],
    "class": ["CLASS_W", "CLASS_M", "CLASS_C", "CLASS_L", "CLASS_TOP"],
    "park": ["PARK_W", "PARK_M", "PARK_C", "PARK_L", "PARK_TOP", "PARK_LOW", "PARK_SIDE",
             "PARK_NE", "PARK_SW"],
    "shop": ["SHOP_W", "SHOP_M", "SHOP_C", "SHOP_L"],
    "kitchen": ["KITCHEN_W", "KITCHEN_M", "KITCHEN_C", "KITCHEN_DOOR"],
    "bedroom": ["BEDROOM_W", "BEDROOM_M", "BEDROOM_C"],
    "cellar": ["CELLAR_W", "CELLAR_M", "CELLAR_C", "CELLAR_UP", "CELLAR_DARK"],
}

# chỗ đứng của nhân vật (tránh bàn, giường, quầy, hòm) — toạ độ trong khu
# trong nhà: đồ đạc dồn về nửa -y (tường hậu), diễn viên đứng gần tường hậu,
# camera lùi về phía +y — nhờ vậy không có bàn ghế nào nằm giữa ống kính và diễn viên
STAGE = {
    "street": (0.0, 0.0), "hall": (0.0, -2.0), "class": (0.0, -2.0), "park": (0.0, 4.0),
    "shop": (0.0, -2.0), "kitchen": (0.0, -2.0), "bedroom": (0.0, 2.0), "cellar": (0.0, -2.0),
}
# vùng ĐI LẠI ĐƯỢC của khu ngoài trời: hàng nhà ở phố chiếm |y| > 15,5
# nên camera phải nằm trong |y| <= 14, không thì đứng ngay trong tường nhà
LIMIT = {"street": (60.0, 15.0), "park": (36.0, 22.0)}

# chiều cao trần từng phòng (dùng cho rig TOP: không đặt camera trên trần)
CEIL = {"hall": 10.0, "class": 10.0, "shop": 10.0, "kitchen": 9.0,
        "bedroom": 9.0, "cellar": 9.0}

MARKS = ["%s_MK%d" % (z.upper(), i) for z in ZONE for i in (1, 2, 3)]

# trong phòng không có đủ 13 stud để lùi: cho phép nhân vật to hơn 1,25 lần
# (cảnh trung trong nhà), và dải hợp lệ cũng giãn theo đúng hệ số đó
INTERIOR_SCALE = 1.25


def back_for(kind, fov=None):
    """Khoảng cách cần để nhân vật chiếm đúng `frac` chiều cao khung."""
    k = KIND[kind]
    f = fov or k["fov"]
    return (BODY / k["frac"]) / (2.0 * math.tan(math.radians(f) / 2.0))


def _build():
    rigs = {}
    for zone, names in RIG_NAMES.items():
        w, d = ZONE[zone]
        ox, oy, oz = ORIGIN[zone]
        interior = zone not in ("street", "park")
        scale = INTERIOR_SCALE if interior else 1.0
        for name in names:
            kind = name.split("_")[1]
            k = KIND.get(kind, KIND["M"])
            sx, sy = STAGE[zone]
            fov = k["fov"]
            back = (BODY / (k["frac"] * scale)) / (2.0 * math.tan(math.radians(fov) / 2.0))
            # rig chéo: `back` là khoảng cách TỔNG, trừ phần lệch ngang
            if k["side"]:
                back = math.sqrt(max(back * back - k["side"] * k["side"], 1.0))
            if interior:
                back = min(back, d / 2.0 - 2.0)          # lùi vào trong phòng
                cy = sy + back                            # camera ở nửa +y, đồ đạc ở nửa -y
            else:
                cy = sy + back
            lim_y = d / 2.0 - 1.5
            lim_x = w / 2.0 - 1.5
            if zone in LIMIT:                          # ngoài trời: giới hạn vùng đi lại
                lim_x = min(lim_x, LIMIT[zone][0])
                lim_y = min(lim_y, LIMIT[zone][1])
            cy = max(-lim_y, min(lim_y, cy))
            cx = max(-lim_x, min(lim_x, k["side"] + sx))
            pos = [ox + cx, oy + cy, oz + k["high"]]
            tgt = [ox + sx, oy + sy, oz + BODY * k["look"]]
            if kind == "SIGN":                            # cảnh 1: Bo ở tiền cảnh, biển phía sau
                pos = [ox + sx - 1.5, oy + sy + 13.5, oz + 3.0]
                tgt = [ox + sx, oy + sy - 10.0, oz + 5.2]
            if kind == "TOP":
                # nhìn từ trên xuống thì thân người bị thu ngắn: không tính khoảng cách
                # theo frac hình học được, phải đặt gần (đo thực nghiệm: 5–6 stud ngang)
                high = min(k["high"], (CEIL[zone] - 1.5) if interior else k["high"])
                back = min(5.5, lim_y - abs(sy))
                pos = [ox + sx + k["side"], oy + sy + back, oz + high]
            b = BAND[kind]
            rigs[name] = dict(zone=zone, pos=pos, tgt=tgt, fov=fov,
                              roll=8.0 if kind == "TILT" else 0.0, kind=kind,
                              band=(round(b[0] * scale, 2), round(b[1] * scale, 2)))
    return rigs


RIGS = _build()


def mark_pos(name):
    zone = name.split("_")[0].lower()
    ox, oy, oz = ORIGIN[zone]
    sx, sy = STAGE[zone]
    i = int(name.split("MK")[1]) - 1
    return (ox + sx + (0.0, -2.5, 2.5)[i], oy + sy, oz)


def face_camera(pos, target_of_mark):
    """Yaw (độ) để nhân vật quay mặt về phía camera."""
    dx = pos[0] - target_of_mark[0]
    dy = pos[1] - target_of_mark[1]
    return math.degrees(math.atan2(dx, dy)) + 180.0


def _lerp(a, b, t):
    return a + (b - a) * t
