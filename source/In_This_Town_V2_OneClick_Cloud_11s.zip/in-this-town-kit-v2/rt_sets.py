"""rt_sets.py — V2: 8 bối cảnh. V1 chỉ có street + một room.

Mỗi bối cảnh nằm ở ORIGIN riêng (rt_cam.ORIGIN) để không chồng lên nhau.
Collection name = tên khu, nên E.use("park", "bo") bật/tắt được từng set.
"""
import rt_engine as E
from rt_engine import M, Static, coll
import rt_rigs as rt_cam

P = dict(cream=(223, 220, 200), sand=(203, 179, 130), wood=(123, 87, 55), bluegrey=(124, 145, 166),
         paleblue=(169, 186, 202), darkbrown=(71, 59, 53), nearblack=(48, 40, 33), red=(193, 73, 51),
         green=(74, 116, 62), tiles=(168, 170, 178), white=(236, 236, 240))


class Set:
    def __init__(self, name):
        self.name = name
        self.c = coll(name)
        self.o = E.Vector(rt_cam.ORIGIN[name])
        self.w = rt_cam.ZONE[name][0]
        self.d = rt_cam.ZONE[name][1]

    def P(self, x, y, z=0.0):
        return tuple(self.o + E.Vector((x, y, z)))

    def show(self, hide=()):
        pass


def _room(name, wall="cream", floor="wood", h=10.0):
    s = Set(name)
    st = Static(s.c, s.o)
    ox, oy, oz = rt_cam.ORIGIN[name]
    mf = M(name + "_floor", P[floor], rough=0.4, tex="planks", spec=0.55)
    mw = M(name + "_wall", P[wall], rough=0.9, tex="noise", ts=0.6, amt=0.12)
    mt = M(name + "_trim", P["white"], rough=0.5)
    st.box(mf, (s.w, s.d, 0.4), (0, 0, -0.2), bevel=0)
    st.done(name + "_floor", shadow=False)
    for key, size, loc in (("n", (s.w, 0.5, h), (0, s.d / 2 + 0.25, h / 2)),
                           ("s", (s.w, 0.5, h), (0, -s.d / 2 - 0.25, h / 2)),
                           ("e", (0.5, s.d, h), (s.w / 2 + 0.25, 0, h / 2)),
                           ("w", (0.5, s.d, h), (-s.w / 2 - 0.25, 0, h / 2))):
        s2 = Static(s.c, s.o)
        s2.box(mw, size, loc, bevel=0)
        s2.box(mt, (size[0] if key in "ns" else 0.28, 0.28 if key in "ns" else size[1], 0.7),
               (loc[0], loc[1], 0.35), bevel=0.03)
        s2.done(f"{name}_w{key}")
    s3 = Static(s.c, s.o)
    s3.box(M(name + "_ceil", (250, 250, 250), rough=0.9), (s.w + 1, s.d + 1, 0.4), (0, 0, h + 0.2), bevel=0)
    s3.done(name + "_ceil", shadow=False)
    # cửa sổ sáng ở vách bắc để có nắng vào phòng
    s4 = Static(s.c, s.o)
    s4.box(M(name + "_win", (250, 246, 232), rough=0.2, emit=(255, 250, 235), emit_k=1.4),
           (6, 0.2, 4), (0, s.d / 2 - 0.35, 6.0), bevel=0.05)
    s4.done(name + "_win")
    return s


def street():
    s = E.Street()
    st = Static(s.c, E.Vector((0, 0, 0)))
    wood = M("st_wood", P["wood"], rough=0.65, tex="planks")
    red = M("st_red", P["red"], rough=0.6)
    grn = M("st_grn", P["green"], rough=0.7)
    for x in (-42, -18, 16, 38):                       # chợ cóc hai bên vỉa hè
        st.box(wood, (6, 2.4, 0.25), (x, -7.5, 3.2), bevel=0.04)
        st.box(wood, (0.3, 0.3, 3.2), (x - 2.6, -7.5, 1.6), bevel=0.03)
        st.box(wood, (0.3, 0.3, 3.2), (x + 2.6, -7.5, 1.6), bevel=0.03)
        for k in range(4):
            st.box(red if k % 2 else grn, (0.7, 0.7, 0.7), (x - 2 + k * 1.3, -7.5, 3.7), bevel=0.08)
    for x in (-30, 4, 26):                             # biển hiệu treo
        st.cyl(M("st_pole", P["nearblack"], rough=0.4), 0.18, 7.0, (x, 8.5, 3.5), n=10)
        st.box(M("st_sign", P["cream"], rough=0.5), (3.2, 0.16, 1.0), (x, 8.5, 7.0), bevel=0.03)
    st.done("street_extra")
    return s


def park():
    s = Set("park")
    st = Static(s.c, s.o)
    grass = M("pk_grass", P["green"], rough=0.95, tex="grass")
    path = M("pk_path", P["tiles"], rough=0.85, tex="tiles")
    wood = M("pk_wood", P["wood"], rough=0.7, tex="planks")
    white = M("pk_white", P["white"], rough=0.5)
    st.box(grass, (s.w + 60, s.d + 60, 0.6), (0, 0, -0.3), bevel=0)
    st.box(path, (s.w, 6, 0.1), (0, 0, 0.05), bevel=0)
    st.box(path, (6, s.d, 0.1), (0, 0, 0.05), bevel=0)
    for x in (-14, 14):                                # khung thành (sau lưng nhân vật)
        st.box(white, (0.4, 0.4, 3.0), (x, 19, 1.5), bevel=0.03)
    st.box(white, (28.4, 0.4, 0.4), (0, 19, 3.0), bevel=0.03)
    for x, y in ((-20, -12), (0, -15), (20, -12)):      # ghế đá, sau lưng diễn viên
        st.box(wood, (6.0, 1.8, 0.4), (x, y, 1.5), bevel=0.08)
        st.box(wood, (6.0, 0.4, 1.6), (x, y - 0.7, 2.4), bevel=0.06)
        st.box(wood, (0.5, 1.6, 1.5), (x - 2.6, y, 0.75), bevel=0.05)
        st.box(wood, (0.5, 1.6, 1.5), (x + 2.6, y, 0.75), bevel=0.05)
    trunk = M("pk_trunk", (96, 62, 40), rough=0.85, tex="noise", ts=4.0, amt=0.35)
    leaf = M("pk_leaf", (44, 128, 56), rough=0.85, tex="noise", ts=3.0, amt=0.3)
    leaf2 = M("pk_leaf2", (78, 158, 62), rough=0.85, tex="noise", ts=3.0, amt=0.3)
    seed = 7
    for i in range(25):                                # 25 cây, cụm tự nhiên
        seed = (seed * 1103515245 + 12345) % 2147483648
        x = (seed % 1000) / 1000.0 * (s.w - 10) - (s.w - 10) / 2
        y = ((seed // 1000) % 1000) / 1000.0 * (s.d - 10) - (s.d - 10) / 2
        if abs(x) < 6 or abs(y) < 6:
            continue
        h = 5.0 + (i % 3)
        st.box(trunk, (1.2, 1.2, h), (x, y, h / 2), bevel=0.2)
        st.blob(leaf if i % 2 else leaf2, 3.4 + (i % 3) * 0.5, (x, y, h + 2.0))
    for i in range(14):
        st.box(M("pk_bush", (58, 110, 50), rough=0.95, tex="grass"), (1.6, 1.6, 1.4),
               (((i * 37) % 60) - 30, ((i * 53) % 34) - 17, 0.7), bevel=0.4)
    st.done("park_set")
    return s


def hall():
    """Hành lang: cửa hai bên tường, ghế + bảng ở nửa -y (sau lưng diễn viên)."""
    s = _room("hall", wall="paleblue", floor="tiles")
    st = Static(s.c, s.o)
    wood = M("hl_wood", P["wood"], rough=0.6, tex="planks")
    blue = M("hl_door", (58, 96, 140), rough=0.5)
    for y in range(-14, 15, 7):                        # 8 cửa hai bên tường dọc
        for sx in (1, -1):
            st.box(blue, (0.25, 4.0, 8.0), (sx * (s.w / 2 - 0.15), y, 4.0), bevel=0.05)
            st.box(M("hl_knob", (250, 205, 80), rough=0.3), (0.3, 0.22, 0.22),
                   (sx * (s.w / 2 - 0.35), y + 1.5, 4.0), bevel=0.04)
    for x in (-12, 0, 12):                             # ghế hành lang, sau lưng diễn viên
        yy = -(s.d / 2 - 4.0)
        st.box(wood, (8.0, 1.6, 0.4), (x, yy, 1.5), bevel=0.06)
        st.box(wood, (0.4, 1.4, 1.5), (x - 3.8, yy, 0.75), bevel=0.04)
        st.box(wood, (0.4, 1.4, 1.5), (x + 3.8, yy, 0.75), bevel=0.04)
    st.box(M("hl_board", (40, 46, 54), rough=0.8), (10, 0.3, 5.0), (0, -(s.d / 2 - 0.3), 6.0), bevel=0.05)
    for i in range(6):
        st.box(M("hl_paper", P["cream"], rough=0.9), (1.4, 0.1, 1.8), (-4 + i * 1.7, -(s.d / 2 - 0.5), 6.0), bevel=0.02)
    st.done("hall_set")
    return s


def class_room():
    """Lớp: bảng ở tường hậu -y, 20 bàn dồn nửa -y, camera ở nửa +y trống."""
    s = _room("class", wall="cream", floor="wood")
    st = Static(s.c, s.o)
    wood = M("cl_wood", (150, 104, 62), rough=0.55, tex="planks")
    st.box(M("cl_frame", P["wood"], rough=0.6, tex="planks"), (17, 0.5, 7.8), (0, -(s.d / 2 - 0.5), 5.5), bevel=0.06)
    st.box(M("cl_board", (52, 62, 50), rough=0.9), (16, 0.4, 7), (0, -(s.d / 2 - 0.4), 5.5), bevel=0.05)
    for r in range(4):                                 # 20 bàn, từ tường hậu ra giữa phòng
        for c in range(5):
            x, y = -14 + c * 7, -(s.d / 2 - 4.0) + r * 3.0
            st.box(wood, (5.0, 2.0, 0.25), (x, y, 2.4), bevel=0.05)
            st.box(wood, (0.25, 0.25, 2.4), (x - 2.2, y - 0.8, 1.2), bevel=0.03)
            st.box(wood, (0.25, 0.25, 2.4), (x + 2.2, y - 0.8, 1.2), bevel=0.03)
            st.box(M("cl_chair", (70, 96, 130), rough=0.7), (1.8, 1.8, 0.2), (x, y + 1.8, 2.2), bevel=0.05)
    st.box(M("cl_map", P["paleblue"], rough=0.9), (10, 0.2, 6), (-s.w / 2 + 0.45, -4, 5.5), bevel=0.03)
    st.done("class_set")
    return s


def shop():
    """Tạp hoá: quầy + bao tải ở tường hậu -y, kệ dọc hai bên, camera nửa +y trống."""
    s = _room("shop", wall="sand", floor="tiles")
    st = Static(s.c, s.o)
    wood = M("sh_wood", P["wood"], rough=0.6, tex="planks")
    yy = -(s.d / 2 - 4.5)
    st.box(wood, (s.w - 4, 2.4, 3.0), (0, yy, 1.5), bevel=0.08)
    st.box(M("sh_top", (208, 196, 168), rough=0.4, tex="noise"), (s.w - 4.4, 2.6, 0.2), (0, yy, 3.1), bevel=0.04)
    for i in range(3):                                 # 3 dãy kệ dọc hai bên tường
        y = -(s.d / 2 - 6.0) + i * 4.2
        for sx in (1, -1):
            x = sx * (s.w / 2 - 2.6)
            st.box(wood, (1.6, s.d - 14, 0.2), (x, y, 2.0), bevel=0.04)
            st.box(wood, (1.6, s.d - 14, 0.2), (x, y, 4.0), bevel=0.04)
            for k in range(5):
                st.box(M("sh_goods%d" % (k % 3), ((200, 96, 70), (220, 190, 90), (110, 150, 190))[k % 3], rough=0.6),
                       (1.2, 1.2, 1.6), (x, y - 4 + k * 2.0, 2.9), bevel=0.08)
    for i in range(5):                                 # bao tải góc tường hậu
        st.box(M("sh_sack", (196, 176, 130), rough=0.95, tex="fabric"), (2.0, 2.0, 2.6),
               (-15 + i * 1.9, yy - 2.0, 1.3), bevel=0.3)
    st.box(M("sh_sign", P["red"], rough=0.5), (14, 0.2, 3), (0, -(s.d / 2 - 0.6), 8.0), bevel=0.04)
    st.done("shop_set")
    return s


def kitchen():
    """Bếp: bếp + chạn ở tường hậu -y, bàn dạt bên, camera nửa +y trống."""
    s = _room("kitchen", wall="cream", floor="wood", h=9.0)
    st = Static(s.c, s.o)
    wood = M("kt_wood", (140, 96, 60), rough=0.55, tex="planks")
    yy = -(s.d / 2 - 2.5)
    st.box(wood, (10, 3, 2.8), (0, yy, 1.4), bevel=0.06)          # bàn bếp sát tường hậu
    st.box(M("kt_stove", (70, 74, 82), rough=0.4), (5, 3, 3.0), (0, yy, 1.5), bevel=0.06)
    st.box(M("kt_fire", (255, 150, 60), rough=0.3, emit=(255, 140, 50), emit_k=1.6),
           (2.6, 2.6, 0.2), (0, yy, 3.15), bevel=0.05)
    st.box(wood, (8, 0.6, 0.2), (-1, yy, 5.0), bevel=0.03)        # chạn bát trên cao
    for i in range(4):
        st.box(M("kt_jar%d" % i, ((190, 120, 80), (150, 170, 120), (200, 200, 190), (170, 90, 90))[i], rough=0.4),
               (1.2, 1.2, 1.6), (-4 + i * 2, yy, 5.9), bevel=0.1)
    st.box(wood, (7, 4, 0.3), (11, -(s.d / 2 - 9.0), 3.0), bevel=0.05)   # bàn ăn dạt bên trái
    for dx, dy in ((-3, -1.4), (3, -1.4), (-3, 1.4), (3, 1.4)):
        st.box(wood, (0.3, 0.3, 3.0), (11 + dx, -(s.d / 2 - 9.0) + dy, 1.5), bevel=0.03)
    for x, y in ((-4.2, 0), (4.2, 0)):
        st.box(M("kt_stool", (86, 120, 90), rough=0.7), (1.6, 1.6, 0.25), (x, yy + 2.6, 2.0), bevel=0.06)
        st.box(M("kt_stool", (86, 120, 90), rough=0.7), (1.6, 1.6, 0.25), (x, yy + 2.6, 2.0), bevel=0.06)
    st.done("kitchen_set")
    return s


def bedroom():
    """Buồng ngủ: giường + tủ ở nửa -y, diễn viên đứng trước giường, camera nửa +y."""
    s = _room("bedroom", wall="bluegrey", floor="wood", h=9.0)
    st = Static(s.c, s.o)
    wood = M("bd_wood", (104, 68, 44), rough=0.45, tex="noise", ts=3.0, amt=0.25)
    yy = -(s.d / 2 - 6.0)
    st.box(wood, (6, 9, 0.8), (0, yy, 0.9), bevel=0.1)
    st.box(M("bd_sheet", (226, 226, 232), rough=0.9, tex="fabric"), (5.6, 9.2, 1.0), (0, yy, 1.7), bevel=0.2)
    st.box(M("bd_cover", (44, 62, 128), rough=0.9, tex="fabric"), (5.8, 5.6, 1.1), (0, yy + 1.2, 2.3), bevel=0.25)
    st.box(wood, (2.2, 2.0, 2.2), (9.0, yy + 3.2, 1.1), bevel=0.08)          # tủ đầu giường
    st.box(M("bd_clock", (30, 34, 40), rough=0.3), (1.0, 0.4, 0.8), (9.0, yy + 3.2, 2.6), bevel=0.06)
    st.box(wood, (6, 3, 8), (-s.w / 2 + 3.2, yy - 2.0, 4.0), bevel=0.08)     # tủ áo góc hậu
    st.box(M("bd_rug", (150, 90, 80), rough=0.95, tex="fabric"), (8, 5, 0.1), (0, yy + 7.0, 0.05), bevel=0.02)
    st.done("bedroom_set")
    return s


def cellar():
    """Hầm: hòm + thùng + cầu thang dồn nửa -y, camera nửa +y."""
    s = _room("cellar", wall="darkbrown", floor="nearblack", h=9.0)   # nhân vật 6,2 stud, trần 6,0 là xuyên
    st = Static(s.c, s.o)
    wood = M("cl2_wood", (92, 70, 50), rough=0.8, tex="planks")
    yy = -(s.d / 2 - 4.0)
    for i in range(6):
        st.box(wood, (2.2, 2.2, 2.2), (-6 + (i % 3) * 3.2, yy + (i // 3) * 3.0, 1.1), bevel=0.06)
    for i in range(4):
        st.cyl(M("cl2_barrel", (110, 80, 54), rough=0.7, tex="noise"), 1.3, 2.6, (8, yy + i * 3.0, 1.3), n=14)
    for i in range(4):
        st.box(wood, (4, 0.9, 0.3), (0, yy + 6.0 + i * 1.2, 2.4 - i * 0.6), bevel=0.03)
    st.done("cellar_set")
    return s


BUILDERS = dict(street=street, park=park, hall=hall, **{"class": class_room}, shop=shop,
                kitchen=kitchen, bedroom=bedroom, cellar=cellar)


def build(only=None):
    out = {}
    for k, fn in BUILDERS.items():
        if only and k not in only:
            continue
        out[k] = fn()
    return out
